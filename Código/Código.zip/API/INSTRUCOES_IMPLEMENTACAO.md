# Como rodar e o que foi implementado

Este projeto JavaFX Maven conecta no MySQL (`SAMBOLDAPI`) e já contém:
- Login e Cadastro (cadastro força `perfil=1` aluno e `_status=1`).
- Solicitação de orientador pelo aluno e painéis do professor.
- Aceitar/Recusar no professor (HomeP) e bloqueio automático do fluxo de solicitação quando houver aceite.
- Chat persistente em banco: tabela `chat` guarda o histórico como JSON no campo `arquivo`.
- Script SQL compatível com MySQL 8: `db/schema.sql`.

## Passo a passo

1. **MySQL**
   ```sql
   SOURCE db/schema.sql;
   ```
   Altere a senha do root e a URL no arquivo `Database.java` se necessário.

2. **Rodar**
   ```bash
   mvn -q clean javafx:run
   ```

3. **Fluxo**
   - Cadastre um aluno: o backend salva `perfil=1` e `_status=1`.
   - Faça login com aluno. Se não existir aceitação, abre **Aluno-Solicita** para escolher professor.
   - Entre com um professor (perfil 2) para enxergar as solicitações do lado direito e **Aceitar** ou **Recusar**.
   - Quando **Aceitar**, o aluno, no próximo login, é levado direto para **Home Aluno** com acesso ao **Chat**.
   - O **Chat** salva histórico em `chat.arquivo` como JSON. Ambos veem a mesma conversa.

## Notas de compatibilidade

- O schema original usava `UNIQUE` em BLOB, o que não é suportado sem prefixo. Corrigido no `schema.sql`.
- `solicitacao` usa PK `(email_aluno, email_prof)` e mantém `_status` indexado para simplificar atualização.
- Se já existir base criada, rode um backup e aplique o novo schema manualmente.