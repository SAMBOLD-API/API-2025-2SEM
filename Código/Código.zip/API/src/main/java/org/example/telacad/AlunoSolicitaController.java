package org.example.telacad;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.models.Usuario;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AlunoSolicitaController {

    @FXML private Button solicitarBtn;
    @FXML private Button HomeButton;
    @FXML private VBox sucessoDialog;
    @FXML private VBox mainPanel;
    @FXML private VBox overlayPane;

    @FXML private ToggleGroup professorToggleGroup;
    @FXML private Label statusLabel;

    // 12 slots de VBox (agora controlamos o VBox, não só o ToggleButton)
    @FXML private VBox profVBox1;
    @FXML private VBox profVBox2;
    @FXML private VBox profVBox3;
    @FXML private VBox profVBox4;
    @FXML private VBox profVBox5;
    @FXML private VBox profVBox6;
    @FXML private VBox profVBox7;
    @FXML private VBox profVBox8;
    @FXML private VBox profVBox9;
    @FXML private VBox profVBox10;
    @FXML private VBox profVBox11;
    @FXML private VBox profVBox12;

    private List<VBox> allProfBoxes() {
        return Arrays.asList(
            profVBox1, profVBox2, profVBox3, profVBox4, profVBox5, profVBox6,
            profVBox7, profVBox8, profVBox9, profVBox10, profVBox11, profVBox12
        );
    }

    @FXML
    private void initialize() {
        // Habilita o botão somente quando houver seleção
        // Isso continua funcionando pois o ToggleGroup é definido no FXML
        if (professorToggleGroup != null) {
            professorToggleGroup.selectedToggleProperty().addListener((obs, oldT, sel) -> {
                if (solicitarBtn != null) solicitarBtn.setDisable(sel == null);
            });
        }
        if (solicitarBtn != null) solicitarBtn.setDisable(true);

        carregarProfessoresDoMesmoCurso();
    }

    private void carregarProfessoresDoMesmoCurso() {
        try {
            Usuario alunoLogado = Sessao.getUsuario();
            if (alunoLogado == null) {
                if (statusLabel != null) statusLabel.setText("Faça login novamente.");
                travarTudo();
                return;
            }

            String cursoAluno = alunoLogado.getCurso();

            // Busca somente professores do mesmo curso (perfil 2 ou 3, ativos)
            SolicitacaoDAO dao = new SolicitacaoDAO();
            List<Usuario> professores = dao.listarProfessoresDisponiveis(cursoAluno);
            if (professores == null) professores = new ArrayList<>();

            // Limpa todos os VBox (esconde eles e seus filhos)
            for (VBox vb : allProfBoxes()) {
                if (vb == null) continue;
                
                // Esconde o VBox inteiro
                vb.setVisible(false);
                vb.setManaged(false); 

                // Pega os filhos (Toggle e Label) para limpar
                try {
                    // vb.getChildren().get(0) é o ToggleButton
                    ToggleButton tb = (ToggleButton) vb.getChildren().get(0);
                    // vb.getChildren().get(1) é o Label
                    Label label = (Label) vb.getChildren().get(1);

                    label.setText(""); // Limpa o texto do label
                    tb.setUserData(null);
                    tb.setSelected(false);
                } catch (Exception e) {
                    // Ignora se a estrutura do FXML estiver inesperada
                }
            }

            // Preenche apenas o necessário
            int i = 0;
            for (Usuario p : professores) {
                if (i >= allProfBoxes().size()) break; // Não temos mais slots
                
                VBox vb = allProfBoxes().get(i++);
                if (vb == null) continue;
                
                // Assume que a estrutura é [0: ToggleButton, 1: Label]
                ToggleButton tb = (ToggleButton) vb.getChildren().get(0);
                Label label = (Label) vb.getChildren().get(1);

                // Define o texto do Label com Nome e Email (com quebra de linha)
                label.setText(p.getNome() + "\n(" + p.getEmail() + ")"); 
                
                // Armazena o email no Toggle (para o envio da solicitação)
                tb.setUserData(p.getEmail()); 

                // Mostra o VBox (Bolinha + Label)
                vb.setVisible(true);
                vb.setManaged(true);
            }

            if (statusLabel != null) {
                if (professores.isEmpty()) {
                    statusLabel.setText("Nenhum professor disponível para o seu curso.");
                    if (solicitarBtn != null) solicitarBtn.setDisable(true);
                } else {
                    statusLabel.setText("Selecione um professor do seu curso.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            if (statusLabel != null) statusLabel.setText("Erro ao carregar professores.");
            if (solicitarBtn != null) solicitarBtn.setDisable(true);
        }
    }

    @FXML
    private void sucessoSolicitacao() {
        try {
            Toggle sel = (professorToggleGroup != null) ? professorToggleGroup.getSelectedToggle() : null;
            if (sel == null || sel.getUserData() == null) {
                if (statusLabel != null) statusLabel.setText("Selecione um professor.");
                return;
            }

            Usuario alunoLogado = Sessao.getUsuario();
            if (alunoLogado == null) return;

            String emailAluno = alunoLogado.getEmail();
            String emailProf  = sel.getUserData().toString();

            // Cria ou atualiza a solicitação como pendente (1)
            SolicitacaoDAO dao = new SolicitacaoDAO();
            dao.criarSolicitacao(emailAluno, emailProf, 1); // 1 = pendente

            // feedback de UI
            if (statusLabel != null) statusLabel.setText("Solicitação enviada.");
            if (overlayPane != null) overlayPane.setVisible(true);
            if (sucessoDialog != null) sucessoDialog.setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
            if (statusLabel != null) statusLabel.setText("Falha ao enviar solicitação.");
        }
    }

    @FXML
    private void handleHomeButton() {
        try {
            if (overlayPane != null) overlayPane.setVisible(false);
            if (sucessoDialog != null) sucessoDialog.setVisible(false);

            Parent root = FXMLLoader.load(getClass().getResource("/org/example/telacad/LoginView.fxml"));
            Stage stage = (Stage) mainPanel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void voltar(ActionEvent event) throws IOException {
        Parent loginRoot = FXMLLoader.load(getClass().getResource("/org/example/telacad/LoginView.fxml"));
        Scene loginScene = new Scene(loginRoot);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(loginScene);
        stage.show();
    }

    private void travarTudo() {
        for (VBox vb : allProfBoxes()) {
            if (vb == null) continue;
            
            // Esconde o VBox inteiro
            vb.setVisible(false);
            vb.setManaged(false);
            
            // Desabilita o Toggle lá dentro
            try {
                ToggleButton tb = (ToggleButton) vb.getChildren().get(0);
                tb.setDisable(true);
            } catch (Exception e) {}
        }
        if (solicitarBtn != null) solicitarBtn.setDisable(true);
    }
}