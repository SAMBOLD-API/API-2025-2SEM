package org.example.telacad.models;

public class Solicitacao {
    private String emailAluno;
    private String emailProf;
    private int status; // 1: pendente, 2: aprovada, 3: recusada
    private String nomeAluno; // Para exibição na interface
    private String nomeProf;  // Para exibição na interface

    public String getEmailAluno() { 
        return emailAluno; 
    }
    
    public String getEmailProf() {
         return emailProf; 
    }
    
    public int getStatus() {
         return status; 
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public String getNomeProf() {
        return nomeProf;
    }

    public void setEmailAluno(String emailAluno) {
         this.emailAluno = emailAluno; 
    }
    
    public void setEmailProf(String emailProf) {
         this.emailProf = emailProf; 
    }

    public void setStatus(int status) {
         this.status = status; 
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public void setNomeProf(String nomeProf) {
        this.nomeProf = nomeProf;
    }

    public String getStatusTexto() {
        switch (status) {
            case 1: return "Pendente";
            case 2: return "Aceita";
            case 3: return "Recusada";
            default: return "Desconhecido";
        }
    }
}