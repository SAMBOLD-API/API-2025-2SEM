package org.example.telacad;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class LoginApplication extends Application {

    @Override
public void start(Stage stage) throws Exception {
    var url = getClass().getResource("/org/example/telacad/LoginView.fxml");
    if (url == null) throw new RuntimeException("LoginView.fxml não encontrado");

    FXMLLoader loader = new FXMLLoader(url);
    Parent root = loader.load();
    System.out.println("[APP] FXML: " + loader.getLocation());
    System.out.println("[APP] Controller: " + loader.getController());

    Scene scene = new Scene(root);
    Ui.applyCss(scene);
    stage.setScene(scene);
    stage.setTitle("Tela de Login");

    var b = Screen.getPrimary().getVisualBounds();
    stage.setX(b.getMinX()); stage.setY(b.getMinY());
    stage.setWidth(b.getWidth()); stage.setHeight(b.getHeight());
    stage.show();
}


    public static void main(String[] args) {
        launch(args);
    }
}
