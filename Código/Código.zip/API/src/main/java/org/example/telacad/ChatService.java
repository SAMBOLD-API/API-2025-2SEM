package org.example.telacad;

import java.util.List;

import org.example.telacad.db.ChatMessageDAO;
import org.example.telacad.models.ChatMensagem;
import org.example.telacad.models.Usuario;

public class ChatService {
    private final ChatMessageDAO dao = new ChatMessageDAO();

    public List<ChatMensagem> load(Usuario aluno, Usuario prof, int limit) throws Exception {
    if (!dao.existeVinculoAceito(aluno.getEmail(), prof.getEmail())) {
        throw new IllegalStateException("Não existe vínculo aceito entre os usuários.");
    }
    return dao.listarMensagens(aluno.getEmail(), prof.getEmail(), limit);
}

    public void appendFromAluno(Usuario aluno, Usuario prof, String text) throws Exception {
        if (!dao.existeVinculoAceito(aluno.getEmail(), prof.getEmail())) {
            throw new IllegalStateException("Vínculo não aceito — não é possível enviar mensagem.");
        }
        dao.salvarMensagem(aluno.getEmail(), prof.getEmail(), "aluno", text);
    }

    public void appendFromProf(Usuario aluno, Usuario prof, String text) throws Exception {
        if (!dao.existeVinculoAceito(aluno.getEmail(), prof.getEmail())) {
            throw new IllegalStateException("Vínculo não aceito — não é possível enviar mensagem.");
        }
        dao.salvarMensagem(aluno.getEmail(), prof.getEmail(), "prof", text);
    }
}
