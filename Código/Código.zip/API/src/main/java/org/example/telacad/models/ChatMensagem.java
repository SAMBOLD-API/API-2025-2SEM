package org.example.telacad.models;

import java.time.LocalDateTime;

public class ChatMensagem {
    private long id;
    private String emailAluno;
    private String emailProf;
    private String sender; // "aluno" | "prof"
    private String texto;
    private LocalDateTime createdAt;

    public ChatMensagem(long id, String emailAluno, String emailProf, String sender, String texto, LocalDateTime createdAt) {
        this.id = id;
        this.emailAluno = emailAluno;
        this.emailProf = emailProf;
        this.sender = sender;
        this.texto = texto;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public String getEmailAluno() { return emailAluno; }
    public String getEmailProf() { return emailProf; }
    public String getSender() { return sender; }
    public String getTexto() { return texto; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
