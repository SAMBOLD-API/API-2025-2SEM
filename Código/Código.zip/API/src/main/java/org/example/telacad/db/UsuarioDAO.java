package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import org.example.telacad.models.Usuario;

public class UsuarioDAO {

    // Login simples (senha em texto). Depois você troca por hash se quiser viver perigosamente menos.
    public Usuario validarLogin(String email, String senhaEmTexto) throws SQLException {
        String sql = "SELECT email, nome, curso, senha, perfil, _status " +
                     "FROM usuario WHERE email = ? AND senha = ? AND _status = 1";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, senhaEmTexto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getString("email"),
                            rs.getString("nome"),
                            rs.getString("curso"),
                            rs.getString("senha"),
                            rs.getInt("perfil"),
                            rs.getInt("_status")
                    );
                }
            }
        }
        return null;
    }

    public boolean emailExiste(String email) throws SQLException {
        String sql = "SELECT 1 FROM usuario WHERE email = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void inserirUsuario(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuario (email, nome, curso, senha, perfil, _status) VALUES (?,?,?,?,?,?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getEmail());
            ps.setString(2, u.getNome());
            ps.setString(3, u.getCurso());
            ps.setString(4, u.getSenha());
            ps.setInt(5, u.getPerfil());
            ps.setInt(6, u.getStatus());
            ps.executeUpdate();
        }
    }


    public void cadastrarAlunoBasico(String email, String nome, String curso, String senhaEmTexto) throws SQLException {
    if (email == null || email.isBlank()) throw new IllegalArgumentException("email obrigatório");
    if (nome == null || nome.isBlank()) throw new IllegalArgumentException("nome obrigatório");
    if (senhaEmTexto == null || senhaEmTexto.isBlank()) throw new IllegalArgumentException("senha obrigatória");

    // opcional: evita duplicidade elegante
    if (emailExiste(email)) {
        throw new SQLIntegrityConstraintViolationException("Email já cadastrado: " + email);
    }

    String sql = "INSERT INTO usuario (email, nome, curso, senha, perfil, _status) VALUES (?,?,?,?,1,1)";
    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email.trim());
        ps.setString(2, nome.trim());
        ps.setString(3, (curso == null ? "" : curso.trim()));
        ps.setString(4, senhaEmTexto); // se quiser hash depois, troque aqui
        ps.executeUpdate();
    }
}


    public Usuario buscarPorEmail(String email) throws SQLException {
        String sql = "SELECT email, nome, curso, senha, perfil, _status FROM usuario WHERE email = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getString("email"),
                            rs.getString("nome"),
                            rs.getString("curso"),
                            rs.getString("senha"),
                            rs.getInt("perfil"),
                            rs.getInt("_status")
                    );
                }
            }
        }
        return null;
    }
}
