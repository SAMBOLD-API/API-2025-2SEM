package org.example.telacad;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.models.Solicitacao;
import org.example.telacad.models.Usuario;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class HomePController {

    @FXML private VBox solicitacoesVBox;
    @FXML private TextField messageInputField;
    @FXML private Button addUserButton;
    @FXML private VBox messageVBox;
    @FXML private Button sairBtn;
    @FXML private Button perfilBtn;
    @FXML private VBox listaAlunosVBox;
    @FXML private ScrollPane messageScrollPane;
    @FXML private VBox chatContainer;
    @FXML private Label chatAlunoNomeLabel;
    @FXML private Label emptyChatMessage;
    @FXML private VBox overlayPane;
    @FXML private VBox documentPopupVBox;
    @FXML private Label docEmptyMessageLabel;
    @FXML private ScrollPane docScrollPane;
    @FXML private VBox docListVBox;

    private final List<Aluno> alunosAtivos = new ArrayList<>();
    private String emailAlunoChatAtual = null;

    private static class Aluno {
        final int id;
        final String nome;
        final String email;
        final String status;
        Aluno(int id, String nome, String email, String status) {
            this.id = id;
            this.nome = nome;
            this.email = email;
            this.status = status;
        }
    }

    @FXML
    public void initialize() {
        carregarSolicitacoes();
        carregarAlunosAceitos();

        if (messageInputField != null) {
            messageInputField.setOnAction(this::enviarMensagem);
        }
    }

    @FXML
    private void enviarMensagem(ActionEvent e) {
        try {
            String texto = messageInputField != null ? messageInputField.getText() : "";
            if (texto == null || texto.trim().isEmpty()) return;

            Usuario prof = Sessao.getUsuario();
            if (prof == null) return;
            if (emailAlunoChatAtual == null) return;

            Usuario aluno = new Usuario(emailAlunoChatAtual, chatAlunoNomeLabel.getText(), "", "", 1, 1);

            ChatService chat = new ChatService();
            chat.appendFromProf(aluno, prof, texto);

            Platform.runLater(() -> {
                if (!messageScrollPane.isVisible()) {
                    emptyChatMessage.setVisible(false);
                    messageScrollPane.setVisible(true);
                }
                adicionarMensagem(texto, false); // false = professor
            });

            messageInputField.clear();
            Platform.runLater(() -> {
                if (messageScrollPane != null) messageScrollPane.setVvalue(1.0);
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void carregarAlunosAceitos() {
        try {
            Usuario profLogado = Sessao.getUsuario();
            if (profLogado == null) return;

            SolicitacaoDAO solDAO = new SolicitacaoDAO();
            List<Usuario> alunosAceitosLista = solDAO.listarAlunosAceitos(profLogado.getEmail());

            alunosAtivos.clear();
            int id = 1;
            for (Usuario aluno : alunosAceitosLista) {
                alunosAtivos.add(new Aluno(id++, aluno.getNome(), aluno.getEmail(), "Sem novas mensagens"));
            }

            atualizarListaAlunosUI();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void carregarSolicitacoes() {
        try {
            Usuario profLogado = Sessao.getUsuario();
            if (profLogado == null) return;

            SolicitacaoDAO solDAO = new SolicitacaoDAO();
            List<Solicitacao> solicitacoesPendentes = solDAO.listarSolicitacoesPendentes(profLogado.getEmail());

            if (solicitacoesVBox == null) return;
            solicitacoesVBox.getChildren().clear();

            for (Solicitacao sol : solicitacoesPendentes) {
                solicitacoesVBox.getChildren().add(
                        criarItemSolicitacao(sol.getNomeAluno(), sol.getEmailAluno())
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void atualizarListaAlunosUI() {
        if (listaAlunosVBox == null) return;
        listaAlunosVBox.getChildren().clear();

        for (Aluno a : alunosAtivos) {
            listaAlunosVBox.getChildren().add(
                    criarItemAluno(a.nome, a.status, a.email)
            );
        }
    }

    private HBox criarItemAluno(String nome, String status, String email) {
        StackPane circleContainer = new StackPane(new Circle(22, Color.web("#E0E0E0")));
        circleContainer.setPrefSize(44, 44);

        Label labelNome = new Label(nome);
        labelNome.getStyleClass().add("aluno-name");

        Label labelStatus = new Label(status);
        labelStatus.getStyleClass().add("aluno-status");

        VBox textVBox = new VBox(labelNome, labelStatus);
        textVBox.setAlignment(Pos.CENTER_LEFT);

        HBox item = new HBox(15, circleContainer, textVBox);
        item.getStyleClass().add("list-item");
        item.setAlignment(Pos.CENTER_LEFT);

        item.setOnMouseClicked(event -> abrirChatPopup(nome, email));

        return item;
    }

    private Node criarItemSolicitacao(String nomeAluno, String emailAluno) {
        StackPane circleContainer = new StackPane(new Circle(30, Color.web("#E0E0E0")));
        circleContainer.setPrefSize(60, 60);

        Label labelNome = new Label(nomeAluno);
        labelNome.getStyleClass().add("solicitacao-aluno-name");

        HBox topRow = new HBox(15, circleContainer, labelNome);
        topRow.setAlignment(Pos.CENTER_LEFT);
        topRow.setPadding(new javafx.geometry.Insets(0, 0, 10, 0));

        Button btnAprovar = new Button("APROVAR");
        btnAprovar.getStyleClass().add("btn-aprovar");

        Button btnRecusar = new Button("RECUSAR");
        btnRecusar.getStyleClass().add("btn-recusar");

        btnAprovar.setOnAction(ev -> {
            try {
                Usuario prof = Sessao.getUsuario();
                if (prof == null) return;

                SolicitacaoDAO dao = new SolicitacaoDAO();
                dao.atualizarStatus(emailAluno, prof.getEmail(), 2); // 2 = aceito

                Platform.runLater(() -> abrirChatPopup(nomeAluno, emailAluno));

                carregarSolicitacoes();
                carregarAlunosAceitos();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnRecusar.setOnAction(ev -> {
            try {
                Usuario prof = Sessao.getUsuario();
                if (prof == null) return;
                SolicitacaoDAO dao = new SolicitacaoDAO();
                dao.atualizarStatus(emailAluno, prof.getEmail(), 3); // 3 = recusado
                carregarSolicitacoes();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        HBox hboxBotos = new HBox(10, btnAprovar, btnRecusar);
        hboxBotos.setAlignment(Pos.CENTER);

        VBox itemBox = new VBox(5, topRow, hboxBotos);
        itemBox.getStyleClass().add("solicitacao-item");
        itemBox.setAlignment(Pos.CENTER);
        itemBox.setUserData(emailAluno);

        return itemBox;
    }

    private void abrirChatPopup(String nomeAluno, String emailAluno) {
        try {
            this.emailAlunoChatAtual = emailAluno;

            // abre o popup primeiro
            chatAlunoNomeLabel.setText(nomeAluno);
            messageVBox.getChildren().clear();
            emptyChatMessage.setVisible(true);
            messageScrollPane.setVisible(false);
            overlayPane.setVisible(true);
            chatContainer.setVisible(true);

            Usuario prof = Sessao.getUsuario();
            if (prof == null) return;

            // tenta carregar histórico real
            ChatService chat = new ChatService();
            var msgs = chat.load(
                    new Usuario(emailAluno, nomeAluno, "", "", 1, 1),
                    prof,
                    500
            );

            if (msgs.isEmpty()) {
                emptyChatMessage.setVisible(true);
                messageScrollPane.setVisible(false);
            } else {
                emptyChatMessage.setVisible(false);
                messageScrollPane.setVisible(true);
                for (var m : msgs) {
                    boolean isAluno = "aluno".equalsIgnoreCase(m.getSender());
                    adicionarMensagem(m.getTexto(), isAluno);
                }
                Platform.runLater(() -> messageScrollPane.setVvalue(1.0));
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Mesmo com erro, o popup já está visível; deixa o usuário mandar mensagem.
        }
    }


    private void adicionarMensagem(String texto, boolean isAluno) {
        Label bubble = new Label(texto == null ? "" : texto);
        bubble.setWrapText(true);
        bubble.getStyleClass().add("message-bubble");
        bubble.getStyleClass().add(isAluno ? "student-bubble" : "professor-bubble");

        HBox messageRow = new HBox(bubble);
        messageRow.setAlignment(isAluno ? Pos.CENTER_LEFT : Pos.CENTER_RIGHT);
        messageVBox.getChildren().add(messageRow);

        Platform.runLater(() -> messageScrollPane.setVvalue(1.0));
    }

    @FXML
    private void fecharChat(ActionEvent event) {
        if (chatContainer != null) {
            chatContainer.setVisible(false);
            overlayPane.setVisible(false);
            this.emailAlunoChatAtual = null;
        }
    }

    @FXML
    private void abrirPerfil(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/telacad/Perfil_Professor.fxml"));
            Parent root = loader.load();
            Stage ownerStage = (Stage) perfilBtn.getScene().getWindow();
            Stage popupStage = new Stage();
            popupStage.initStyle(StageStyle.TRANSPARENT);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.initOwner(ownerStage);
            Scene scene = new Scene(root, ownerStage.getWidth(), ownerStage.getHeight());
            scene.setFill(Color.TRANSPARENT);
            popupStage.setScene(scene);
            popupStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addProf(ActionEvent event) {
        try {
            Stage stagePrincipal = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Parent loginPage = FXMLLoader.load(getClass().getResource("/org/example/telacad/Cadastro-prof.fxml"));
            Scene loginScene = new Scene(loginPage);
            stagePrincipal.setScene(loginScene);
            stagePrincipal.setTitle("Cadastro de Professor");
            stagePrincipal.setMaximized(true);
            stagePrincipal.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleOpenDocuments(ActionEvent event) {
        docListVBox.getChildren().clear();
        docEmptyMessageLabel.setVisible(true);
        docScrollPane.setVisible(false);

        overlayPane.setVisible(true);
        documentPopupVBox.setVisible(true);
    }

    @FXML
    private void closeDocumentPopup(ActionEvent event) {
        overlayPane.setVisible(false);
        documentPopupVBox.setVisible(false);
    }

    @FXML
    private void voltarParaLogin(ActionEvent e) {
        try {
            Stage stagePrincipal = (Stage) ((Node)e.getSource()).getScene().getWindow();
            Parent loginPage = FXMLLoader.load(getClass().getResource("/org/example/telacad/LoginView.fxml"));
            Scene loginScene = new Scene(loginPage);
            stagePrincipal.setScene(loginScene);
            stagePrincipal.setTitle("Login");
            stagePrincipal.setMaximized(true);
            stagePrincipal.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
