package org.example.telacad;

public enum TipoProfessor { PROFESSOR, TG }
