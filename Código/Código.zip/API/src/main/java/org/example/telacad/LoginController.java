package org.example.telacad;

import java.net.URL;
import java.util.Objects;

import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.db.UsuarioDAO;
import org.example.telacad.models.Solicitacao;
import org.example.telacad.models.Usuario;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.Window;

public class LoginController {

    @FXML private javafx.scene.control.TextField emailField;
    @FXML private javafx.scene.control.PasswordField passwordField;
    @FXML private javafx.scene.control.Button loginButton;

    @FXML
    private void initialize() {
        System.out.println("[LOGIN] initialize()");
        System.out.println("[LOGIN] emailField != null ? " + (emailField != null));
        System.out.println("[LOGIN] passwordField != null ? " + (passwordField != null));
        System.out.println("[LOGIN] loginButton != null ? " + (loginButton != null));

        // NADA de setOnAction aqui. O FXML já tem onAction="#handleLoginAction".
        // Se meter outro, dispara 2x e dá ruim.
        debugRecursos(); // opcional, ajuda a identificar caminho errado
    }

    @FXML
    private void handleLoginAction(ActionEvent event) {
        System.out.println("[LOGIN] handleLoginAction acionado");
        try {
            String email = (emailField != null) ? emailField.getText() : "";
            String senha = (passwordField != null) ? passwordField.getText() : "";

            if (email == null || email.isBlank() || senha == null || senha.isBlank()) {
                System.err.println("[LOGIN] Email ou senha vazios.");
                return;
            }

            UsuarioDAO dao = new UsuarioDAO();
            Usuario usuario = dao.validarLogin(email, senha);
            if (usuario == null) {
                System.err.println("[LOGIN] Credenciais inválidas.");
                return;
            }

            Sessao.setUsuario(usuario);

            if (usuario.getPerfil() == 1) { // aluno
                SolicitacaoDAO sdao = new SolicitacaoDAO();
                Solicitacao ativa = sdao.buscarSolicitacaoAtiva(usuario.getEmail());
                if (ativa != null && ativa.getStatus() == 2) { // solicitação aceita
                trocarCena(event, "/org/example/telacad/Chat-aluno.fxml", "ChatAluno");
                } else {
                trocarCena(event, "/org/example/telacad/Aluno-Solicita.fxml", "Solicitação");
                }
            } else { // 2 prof, 3 tg
                trocarCena(event, "/org/example/telacad/home-professor.fxml", "Home Professor");
            }

        } catch (Throwable e) {
            e.printStackTrace();
            System.err.println("[LOGIN] Falha geral: " + e.getMessage());
        }
    }

    @FXML
    private void handleGoToCadastro(ActionEvent event) {
        trocarCena(event, "/org/example/telacad/Cadastro-all.fxml", "Cadastro");
    }

    private void trocarCena(ActionEvent event, String fxml, String titulo) {
        System.out.println("[NAV] trocando -> " + fxml + " | " + titulo);
        try {
            URL url = Objects.requireNonNull(getClass().getResource(fxml), "FXML não encontrado: " + fxml);

            FXMLLoader loader = new FXMLLoader(url);
            loader.setControllerFactory(type -> {
                System.out.println("[NAV] Instanciando controller: " + type.getName());
                try {
                    return type.getDeclaredConstructor().newInstance();
                } catch (Throwable t) {
                    t.printStackTrace();
                    throw new RuntimeException("Falha ao instanciar controller " + type.getName(), t);
                }
            });

            Parent root = loader.load(); // se a tela de destino tiver ToggleGroup no children, quebra aqui
            Scene scene = new Scene(root);

            // CSS não pode derrubar troca de cena; se der ruim, só loga
            try {
                Ui.applyCss(scene);
            } catch (Throwable css) {
                System.err.println("[NAV] Falha ao aplicar CSS: " + css.getClass().getSimpleName() + " - " + css.getMessage());
            }

            Stage stage = resolveStage(event);
            if (stage == null) {
                Window win = Stage.getWindows().stream().filter(Window::isShowing).findFirst().orElse(null);
                stage = (win instanceof Stage) ? (Stage) win : new Stage();
            }

            stage.setScene(scene);
            stage.setTitle(titulo != null ? titulo : "");
            // Seu código usava bounds. Aqui vai maximizado, que é mais consistente.
            stage.setMaximized(true);
            // Se você quiser forçar fullscreen igual antes, descomente:
            // var bounds = Screen.getPrimary().getVisualBounds();
            // stage.setX(bounds.getMinX());
            // stage.setY(bounds.getMinY());
            // stage.setWidth(bounds.getWidth());
            // stage.setHeight(bounds.getHeight());
            stage.show();

            System.out.println("[NAV] ok -> " + fxml);
        } catch (Throwable t) {
            logRoot("trocarCena(" + fxml + ")", t);
        }
    }

    private Stage resolveStage(ActionEvent event) {
        try {
            if (event != null && event.getSource() instanceof Node n && n.getScene() != null) {
                Window w = n.getScene().getWindow();
                if (w instanceof Stage) return (Stage) w;
            }
        } catch (Exception ignore) {}
        try {
            if (loginButton != null && loginButton.getScene() != null) {
                Window w = loginButton.getScene().getWindow();
                if (w instanceof Stage) return (Stage) w;
            }
        } catch (Exception ignore) {}
        return null;
    }

    private static void logRoot(String where, Throwable t) {
        System.err.println("[ERR] " + where + " -> " + t);
        Throwable root = t;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();
        System.err.println("[ERR] causa raiz: " + root.getClass().getName() + " - " + root.getMessage());
        for (StackTraceElement ste : root.getStackTrace()) {
            if (ste.getClassName().startsWith("org.example")) {
                System.err.println("[ERR] em " + ste.getClassName() + ":" + ste.getLineNumber());
                break;
            }
        }
    }

    private void debugRecursos() {
        String base = "/org/example/telacad/";
        String[] fs = {"home-aluno.fxml","home-professor.fxml","Aluno-Solicita.fxml","Cadastro-all.fxml"};
        for (String f : fs) {
            System.out.println("[RES] " + f + " => " + getClass().getResource(base + f));
        }
    }
}
