DROP DATABASE IF EXISTS SAMBOLDAPI;
CREATE DATABASE SAMBOLDAPI CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE SAMBOLDAPI;

-- USUÁRIO
CREATE TABLE usuario(
  email  VARCHAR(50)  PRIMARY KEY,
  nome   VARCHAR(100) NOT NULL,
  curso  VARCHAR(250) NOT NULL,
  senha  VARCHAR(255) NOT NULL,
  perfil INT NOT NULL,
  _status TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- SOLICITAÇÃO
CREATE TABLE solicitacao(
  email_aluno VARCHAR(50) NOT NULL,
  email_prof  VARCHAR(50) NOT NULL,
  _status     TINYINT NOT NULL,
  recusa      INT,  #mensagem caso prof recuse a solicitação, cada mensagem é um nmero
  data        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (email_aluno, email_prof, _status),
  CONSTRAINT fk_sol_aluno FOREIGN KEY (email_aluno) REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_sol_prof  FOREIGN KEY (email_prof)  REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- CHAT
CREATE TABLE chat(
  email_aluno VARCHAR(50) NOT NULL,
  email_prof  VARCHAR(50) NOT NULL,
  caminho     VARCHAR(255) NOT NULL,
  PRIMARY KEY (email_aluno, email_prof),
  CONSTRAINT fk_chat_prof  FOREIGN KEY (email_prof)  REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_chat_aluno FOREIGN KEY (email_aluno) REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- CHAT_MENSAGEM
CREATE TABLE chat_mensagem (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  email_aluno VARCHAR(50) NOT NULL,
  email_prof VARCHAR(50) NOT NULL,
  sender VARCHAR(10) NOT NULL,
  texto TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cm_aluno FOREIGN KEY (email_aluno) REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_cm_prof  FOREIGN KEY (email_prof)  REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_chat_pair (email_aluno, email_prof)
) ENGINE=InnoDB;

-- DOCUMENTO
CREATE TABLE documento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email_aluno VARCHAR(50) NOT NULL,
    email_prof VARCHAR(50) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    
    caminho_arquivo VARCHAR(500) NOT NULL,
    tamanho_bytes BIGINT,
    tipo_arquivo VARCHAR(100),
    data_upload TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doc_aluno FOREIGN KEY (email_aluno) REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_doc_prof FOREIGN KEY (email_prof) REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS secao_0 (
    email_aluno VARCHAR(50)  NOT NULL,
    email_prof VARCHAR (50)  NOT NULL,
    foto_path VARCHAR(500),
    nome_completo VARCHAR(100),
    idade INT,
    curso VARCHAR(250),
    email_contato VARCHAR(100),
    linkedin VARCHAR(255),
    github VARCHAR(255),
    motivacao_fatec TEXT,
    historico_academico TEXT,
    historico_profissional TEXT,
    conhecimentos_tecnicos TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (email_aluno, email_prof),
    CONSTRAINT fk_sec0_aluno FOREIGN KEY (email_aluno) 
        REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS secao_api (
    email_prof VARCHAR (50)  NOT NULL,
    email_aluno VARCHAR(50) NOT NULL,
    numero_secao TINYINT NOT NULL, -- 1 a 6
    empresa_parceira VARCHAR(255),
    problema TEXT,
    solucao TEXT,
    solucao_imagem_path VARCHAR(500), -- caminho da imagem
    repositorio_github VARCHAR(255),
    tecnologias_utilizadas TEXT,
    contribuicoes_pessoais TEXT,
    detalhes_contribuicoes TEXT, -- detalhes extras
    hard_skills TEXT, -- armazenado como JSON ou separado por vírgula
    soft_skills TEXT, -- armazenado como JSON ou separado por vírgula
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (email_prof, email_aluno, numero_secao),
    UNIQUE KEY unique_aluno_secao (email_aluno, numero_secao),
    CONSTRAINT fk_secao_aluno FOREIGN KEY (email_aluno) 
        REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email_aluno VARCHAR(50) NOT NULL,
    email_prof VARCHAR(50) NOT NULL,
    numero_secao TINYINT NOT NULL, -- 0 a 6
    comentario TEXT,
    status_aprovacao TINYINT DEFAULT NULL, -- NULL=sem avaliação, 0=reprovado, 1=aprovado
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_fb_aluno FOREIGN KEY (email_aluno) 
        REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_fb_prof FOREIGN KEY (email_prof) 
        REFERENCES usuario(email) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_secao_api_aluno ON secao_api(email_aluno);
CREATE INDEX idx_feedback_aluno ON feedback(email_aluno);
CREATE INDEX idx_feedback_prof ON feedback(email_prof);
