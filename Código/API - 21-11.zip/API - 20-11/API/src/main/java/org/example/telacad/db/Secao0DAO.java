package org.example.telacad.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Secao0DAO {

    // Salvar/Atualizar Seção 0
    public void salvarSecao0(String emailAluno, String emailProf, String fotoPath, String nomeCompleto, 
                             int idade, String curso, String emailContato, String linkedin, 
                             String github, String motivacao, String histAcademico, 
                             String histProfissional, String conhecimentos) throws SQLException {
        
        String sql = "INSERT INTO secao_0 (email_aluno, email_prof, foto_path, nome_completo, idade, curso, " +
                     "email_contato, linkedin, github, motivacao_fatec, historico_academico, " +
                     "historico_profissional, conhecimentos_tecnicos) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE " +
                     "foto_path = VALUES(foto_path), nome_completo = VALUES(nome_completo), " +
                     "idade = VALUES(idade), curso = VALUES(curso), email_contato = VALUES(email_contato), " +
                     "linkedin = VALUES(linkedin), github = VALUES(github), " +
                     "motivacao_fatec = VALUES(motivacao_fatec), " +
                     "historico_academico = VALUES(historico_academico), " +
                     "historico_profissional = VALUES(historico_profissional), " +
                     "conhecimentos_tecnicos = VALUES(conhecimentos_tecnicos)";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setString(3, fotoPath);
            ps.setString(4, nomeCompleto);
            ps.setInt(5, idade);
            ps.setString(6, curso);
            ps.setString(7, emailContato);
            ps.setString(8, linkedin);
            ps.setString(9, github);
            ps.setString(10, motivacao);
            ps.setString(11, histAcademico);
            ps.setString(12, histProfissional);
            ps.setString(13, conhecimentos);
            ps.executeUpdate();
        }
    }

    // Carregar Seção 0
    public Secao0Data carregarSecao0(String emailAluno) throws SQLException {
        String sql = "SELECT * FROM secao_0 WHERE email_aluno = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Secao0Data(
                        rs.getString("email_aluno"),
                        rs.getString("email_prof"),
                        rs.getString("foto_path"),
                        rs.getString("nome_completo"),
                        rs.getInt("idade"),
                        rs.getString("curso"),
                        rs.getString("email_contato"),
                        rs.getString("linkedin"),
                        rs.getString("github"),
                        rs.getString("motivacao_fatec"),
                        rs.getString("historico_academico"),
                        rs.getString("historico_profissional"),
                        rs.getString("conhecimentos_tecnicos")
                    );
                }
            }
        }
        return null;
    }

    // Verificar se a Seção 0 já foi enviada
    public boolean secaoEnviada(String emailAluno, String emailProf) throws SQLException {
        String sql = "SELECT COUNT(*) FROM secao_0 WHERE email_aluno = ? AND email_prof = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }


    public static class Secao0Data {
        public final String emailAluno, emailProf, fotoPath, nomeCompleto, curso, emailContato;
        public final String linkedin, github, motivacao, histAcademico, histProfissional, conhecimentos;
        public final int idade;

        public Secao0Data(String emailAluno, String emailProf, String fotoPath, String nomeCompleto, int idade,
                         String curso, String emailContato, String linkedin, String github,
                         String motivacao, String histAcademico, String histProfissional, String conhecimentos) {
            this.emailAluno = emailAluno;
            this.emailProf = emailProf;
            this.fotoPath = fotoPath;
            this.nomeCompleto = nomeCompleto;
            this.idade = idade;
            this.curso = curso;
            this.emailContato = emailContato;
            this.linkedin = linkedin;
            this.github = github;
            this.motivacao = motivacao;
            this.histAcademico = histAcademico;
            this.histProfissional = histProfissional;
            this.conhecimentos = conhecimentos;
        }
    }
}
