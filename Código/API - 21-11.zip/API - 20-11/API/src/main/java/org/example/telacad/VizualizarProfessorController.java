package org.example.telacad;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import org.example.telacad.db.SecaoStatusDAO;
import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.db.UsuarioDAO;
import org.example.telacad.models.Usuario;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class VizualizarProfessorController implements Initializable {

    // --- PERFIL (lado esquerdo) ---
    @FXML private TextField nomeField;
    @FXML private TextField emailField;
    @FXML private TextField cursosField;
    @FXML private TextField situacaoField;
    @FXML private Button ativarButton;
    @FXML private Button atualizarButton;
    @FXML private Label closeButton;
    @FXML private Label professorTitleLabel;

    // --- ORIENTAÇÕES (lado direito) ---
    @FXML private BarChart<String, Number> orientacoesChart;
    @FXML private ListView<String> alunosListView;
    @FXML private javafx.scene.layout.Region totalOrientacoesBox;
    @FXML private javafx.scene.layout.Region pendentesBox;
    @FXML private javafx.scene.layout.Region emAndamentoBox;
    @FXML private javafx.scene.layout.Region concluidosBox;

    // Labels com os números dentro dos cards
    @FXML private Label totalOrientacoesLabel;
    @FXML private Label pendentesLabel;
    @FXML private Label emAndamentoLabel;
    @FXML private Label concluidosLabel;

    // --- Popups ---
    @FXML private VBox overlayPane;
    @FXML private VBox confirmacaoDialog;
    @FXML private VBox sucessoDialog;
    @FXML private Label confirmMessageLabel;
    @FXML private Button confirmSimButton;
    @FXML private Button confirmNaoButton;
    @FXML private Label confirmCloseButton;
    @FXML private Label successMessageLabel;
    @FXML private Button successOkButton;

    // --- Popup de cursos ---
    @FXML private VBox cursosDialog;
    @FXML private VBox cursosCheckBoxContainer;
    @FXML private Button cursosOkButton;

    private final List<String> TODOS_OS_CURSOS = Arrays.asList(
            "Análise e Desenvolvimento de Sistemas",
            "Banco de Dados",
            "Desenvolvimento de Software Multiplataforma",
            "Gestão da Produção Industrial",
            "Gestão Empresarial",
            "Logística",
            "Manufatura Avançada",
            "Manutenção de Aeronaves",
            "Projetos de Estruturas Aeronáuticas"
    );

    private List<CheckBox> cursosCheckBoxes = new ArrayList<>();

    // ========= DADOS DO PROFESSOR SELECIONADO =========
    private Usuario professorAtual;
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final SecaoStatusDAO secaoStatusDAO = new SecaoStatusDAO();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // Começa como Inativo só pra não ficar vazio
        atualizarEstadoAtivacao(false);

        if (nomeField != null)  nomeField.setOnKeyTyped(e -> modoEdicao(true));
        if (emailField != null) emailField.setOnKeyTyped(e -> modoEdicao(true));

        // Configura gráfico
        if (orientacoesChart != null) {
            orientacoesChart.setLegendVisible(false);
            orientacoesChart.getData().clear();
        }

        // Popups comuns
        if (confirmNaoButton != null) {
            confirmNaoButton.setOnAction(e -> hidePopups());
        }
        if (confirmCloseButton != null) {
            confirmCloseButton.setOnMouseClicked(e -> hidePopups());
        }
        if (successOkButton != null) {
            successOkButton.setOnAction(e -> hidePopups());
        }

        // Checkboxes de cursos
        if (cursosCheckBoxContainer != null) {
            cursosCheckBoxContainer.getChildren().clear();
            cursosCheckBoxes.clear();

            for (String curso : TODOS_OS_CURSOS) {
                CheckBox cb = new CheckBox(curso);
                cb.getStyleClass().add("popup-checkbox");
                cursosCheckBoxes.add(cb);
                cursosCheckBoxContainer.getChildren().add(cb);
            }
        }

        // Botão OK do popup de cursos
        if (cursosOkButton != null) {
            cursosOkButton.setOnAction(e -> onCursosOkClicked());
        }
    }

    // =====================================================
    // MÉTODOS PÚBLICOS PARA RECEBER O PROFESSOR SELECIONADO
    // =====================================================

    public void setProfessor(Usuario professor) {
        this.professorAtual = professor;
        preencherCamposProfessor();
        carregarOrientacoesProfessor();
    }

    public void setProfessorEmail(String email) {
        try {
            Usuario u = usuarioDAO.buscarPorEmail(email);
            if (u != null) {
                setProfessor(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =======================
    // PREENCHER CAMPOS PERFIL
    // =======================

    private void preencherCamposProfessor() {
        if (professorAtual == null) return;

        if (professorTitleLabel != null) {
            String titulo = professorAtual.getNome() != null && !professorAtual.getNome().isBlank()
                    ? professorAtual.getNome().toUpperCase()
                    : "PROFESSOR";
            professorTitleLabel.setText(titulo);
        }

        if (nomeField != null)  nomeField.setText(professorAtual.getNome());
        if (emailField != null) emailField.setText(professorAtual.getEmail());
        if (cursosField != null) cursosField.setText(professorAtual.getCurso());

        boolean ativo = professorAtual.getStatus() == 1;
        atualizarEstadoAtivacao(ativo);

        // marca checkboxes dos cursos já cadastrados
        if (cursosCheckBoxes != null && professorAtual.getCurso() != null) {
            List<String> cursosAtual = Arrays.stream(professorAtual.getCurso().split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());

            for (CheckBox cb : cursosCheckBoxes) {
                cb.setSelected(cursosAtual.contains(cb.getText()));
            }
        }

        modoEdicao(false);
    }

    // ==============================
    // CARREGAR DADOS DE ORIENTAÇÕES
    // ==============================

    private void carregarOrientacoesProfessor() {
        if (professorAtual == null) return;

        try {
            SolicitacaoDAO solDAO = new SolicitacaoDAO();

            // alunos orientados por este professor
            List<Usuario> alunosOrientados =
                    solDAO.listarAlunosAceitos(professorAtual.getEmail());

            popularListaAlunos(alunosOrientados);

            int totalAlunos   = alunosOrientados.size();
            int semSecao      = 0; // 0 seções
            int parcial       = 0; // entre 1 e 6
            int todasSecoes   = 0; // 7

            for (Usuario aluno : alunosOrientados) {
                int qtdSecoes = secaoStatusDAO
                        .contarSecoesEnviadas(aluno.getEmail(), professorAtual.getEmail());

                if (qtdSecoes == 0) {
                    semSecao++;
                } else if (qtdSecoes >= SecaoStatusDAO.TOTAL_SECOES) {
                    todasSecoes++;
                } else {
                    parcial++;
                }
            }

            // Atualiza números nos cards
            if (totalOrientacoesLabel != null) {
                totalOrientacoesLabel.setText(String.valueOf(totalAlunos));
            }
            if (pendentesLabel != null) {
                pendentesLabel.setText(String.valueOf(semSecao));
            }
            if (emAndamentoLabel != null) {
                emAndamentoLabel.setText(String.valueOf(parcial));
            }
            if (concluidosLabel != null) {
                concluidosLabel.setText(String.valueOf(todasSecoes));
            }

            // Tooltips (se quiser manter)
            if (totalOrientacoesBox != null) {
                Tooltip.install(totalOrientacoesBox,
                        new Tooltip("Total de alunos orientados: " + totalAlunos));
            }
            if (pendentesBox != null) {
                Tooltip.install(pendentesBox,
                        new Tooltip("Sem nenhuma seção enviada: " + semSecao));
            }
            if (emAndamentoBox != null) {
                Tooltip.install(emAndamentoBox,
                        new Tooltip("Com algumas seções enviadas: " + parcial));
            }
            if (concluidosBox != null) {
                Tooltip.install(concluidosBox,
                        new Tooltip("Com todas as seções enviadas: " + todasSecoes));
            }

            // Gráfico com 3 barras
            popularGrafico(semSecao, parcial, todasSecoes);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void popularListaAlunos(List<Usuario> alunos) {
        if (alunosListView == null) return;

        ObservableList<String> itens = FXCollections.observableArrayList();
        for (Usuario u : alunos) {
            String linha = (u.getNome() != null ? u.getNome() : "Aluno") +
                    (u.getEmail() != null ? " (" + u.getEmail() + ")" : "");
            itens.add(linha);
        }
        alunosListView.setItems(itens);
    }

    private void popularGrafico(int semSecao, int parcial, int todasSecoes) {
        if (orientacoesChart == null) return;

        orientacoesChart.getData().clear();
        orientacoesChart.setLegendVisible(false);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Nenhuma", semSecao));
        series.getData().add(new XYChart.Data<>("Parcial", parcial));
        series.getData().add(new XYChart.Data<>("Todas", todasSecoes));

        orientacoesChart.getData().add(series);
    }

    // --- POPUPS ---

    private void hidePopups() {
        if (overlayPane != null) overlayPane.setVisible(false);
        if (confirmacaoDialog != null) confirmacaoDialog.setVisible(false);
        if (sucessoDialog != null) sucessoDialog.setVisible(false);
        if (cursosDialog != null) cursosDialog.setVisible(false);
    }

    private void showSuccessPopup(String message) {
        if (successMessageLabel != null) {
            successMessageLabel.setText(message);
        }
        if (overlayPane != null) overlayPane.setVisible(true);
        if (sucessoDialog != null) sucessoDialog.setVisible(true);
    }

    private void showConfirmationPopup(String message, Runnable onConfirmAction) {
        if (confirmMessageLabel != null) {
            confirmMessageLabel.setText(message);
        }
        if (overlayPane != null) overlayPane.setVisible(true);
        if (confirmacaoDialog != null) confirmacaoDialog.setVisible(true);

        if (confirmSimButton != null) {
            confirmSimButton.setOnAction(e -> {
                confirmacaoDialog.setVisible(false);
                onConfirmAction.run();
            });
        }
    }

    // --- BOTÕES PRINCIPAIS ---

    @FXML
    private void onAtivarClicked() {
        if (professorAtual == null) return;

        boolean estaAtivo = "Ativo".equalsIgnoreCase(situacaoField.getText());
        String acao = estaAtivo ? "desativar" : "ativar";
        String message = "Deseja mesmo " + acao + " este perfil?";

        Runnable onConfirm = () -> {
            try {
                boolean novoAtivo = !estaAtivo;
                int novoStatus = novoAtivo ? 1 : 0;

                usuarioDAO.atualizarStatusUsuario(professorAtual.getEmail(), novoStatus);

                professorAtual = new Usuario(
                        professorAtual.getEmail(),
                        professorAtual.getNome(),
                        professorAtual.getCurso(),
                        professorAtual.getSenha(),
                        professorAtual.getPerfil(),
                        novoStatus
                );

                atualizarEstadoAtivacao(novoAtivo);

                String msgSucesso = novoAtivo
                        ? "Professor ativado com sucesso!"
                        : "Professor desativado com sucesso!";
                showSuccessPopup(msgSucesso);

            } catch (Exception ex) {
                ex.printStackTrace();
                showSuccessPopup("Ocorreu um erro ao alterar o status.");
            }
        };

        showConfirmationPopup(message, onConfirm);
    }

    @FXML
    private void onAtualizarClicked() {
        if (professorAtual == null) {
            showSuccessPopup("Nenhum professor selecionado.");
            return;
        }

        String message = "Deseja mesmo atualizar as informações?";

        Runnable onConfirm = () -> {
            try {
                String nomeDigitado   = nomeField.getText()  != null ? nomeField.getText().trim()  : "";
                String emailDigitado  = emailField.getText() != null ? emailField.getText().trim() : "";
                String cursosDigitado = cursosField.getText() != null ? cursosField.getText().trim() : "";

                boolean nenhumCampoPreenchido =
                        nomeDigitado.isEmpty() &&
                        emailDigitado.isEmpty() &&
                        cursosDigitado.isEmpty();

                if (nenhumCampoPreenchido) {
                    showSuccessPopup("Nenhuma alteração foi informada.");
                    return;
                }

                String nomeFinal   = nomeDigitado.isEmpty()   ? professorAtual.getNome()   : nomeDigitado;
                String emailFinal  = emailDigitado.isEmpty()  ? professorAtual.getEmail()  : emailDigitado;
                String cursosFinal = cursosDigitado.isEmpty() ? professorAtual.getCurso()  : cursosDigitado;

                usuarioDAO.atualizarUsuario(
                        professorAtual.getEmail(), // email antigo
                        emailFinal,
                        nomeFinal,
                        cursosFinal,
                        null // não altera senha
                );

                professorAtual = new Usuario(
                        emailFinal,
                        nomeFinal,
                        cursosFinal,
                        professorAtual.getSenha(),
                        professorAtual.getPerfil(),
                        professorAtual.getStatus()
                );

                preencherCamposProfessor();
                showSuccessPopup("Informações salvas com sucesso!");

            } catch (Exception ex) {
                ex.printStackTrace();
                showSuccessPopup("Erro ao salvar as informações.");
            }
        };

        showConfirmationPopup(message, onConfirm);
    }

    @FXML
    private void onCloseClicked(MouseEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("cadastro-prof.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro");
            alert.setHeaderText(null);
            alert.setContentText("Erro ao carregar a página anterior.");
            alert.showAndWait();
        }
    }

    // --- CURSOS (popup) ---

    @FXML
    private void onCursosClicked() {
        List<String> cursosJaSelecionados = new ArrayList<>();
        if (cursosField.getText() != null && !cursosField.getText().isEmpty()) {
            cursosJaSelecionados = Arrays.asList(cursosField.getText().split(", "));
        }

        for (CheckBox cb : cursosCheckBoxes) {
            cb.setSelected(cursosJaSelecionados.contains(cb.getText()));
        }

        if (overlayPane != null) overlayPane.setVisible(true);
        if (cursosDialog != null) cursosDialog.setVisible(true);
    }

    private void onCursosOkClicked() {
        String cursosTexto = cursosCheckBoxes.stream()
                .filter(CheckBox::isSelected)
                .map(CheckBox::getText)
                .collect(Collectors.joining(", "));

        cursosField.setText(cursosTexto);
        modoEdicao(true);
        hidePopups();
    }

    // --- UTILITÁRIOS ---

    private void atualizarEstadoAtivacao(boolean ativar) {
        if (situacaoField == null || ativarButton == null) return;

        if (ativar) {
            situacaoField.setText("Ativo");
            ativarButton.setText("DESATIVAR");
            ativarButton.getStyleClass().remove("activate-button");
            if (!ativarButton.getStyleClass().contains("deactivate-button")) {
                ativarButton.getStyleClass().add("deactivate-button");
            }
        } else {
            situacaoField.setText("Inativo");
            ativarButton.setText("ATIVAR");
            ativarButton.getStyleClass().remove("deactivate-button");
            if (!ativarButton.getStyleClass().contains("activate-button")) {
                ativarButton.getStyleClass().add("activate-button");
            }
        }
    }

    private void modoEdicao(boolean editando) {
        if (atualizarButton == null || ativarButton == null) return;

        atualizarButton.setVisible(editando);
        ativarButton.setVisible(!editando);
    }
}
