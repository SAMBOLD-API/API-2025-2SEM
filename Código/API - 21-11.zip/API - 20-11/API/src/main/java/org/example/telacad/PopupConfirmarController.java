package org.example.telacad;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class PopupConfirmarController {

    private Secao0Controller secaoController;

    public void setSecaoController(Secao0Controller controller) {
        this.secaoController = controller;
    }

    @FXML
    private void handleConfirmarSim(ActionEvent event) throws IOException {
        // Inicia o fluxo de envio na tela principal
        if (secaoController != null) {
            secaoController.handleEnviarVersao();
        }

        // Fecha o pop-up de confirmação
        closePopup(event);
    }

    @FXML
    private void handleFechar(ActionEvent event) {
        // Fecha o pop-up (chamado pelo botão 'NÃO, SAIR.')
        closePopup(event);
    }

    private void closePopup(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
