package org.example.telacad;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.example.telacad.db.FeedbackDAO;
import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.models.Usuario;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class PerfilAlunoController {

    public enum SectionStatus {
        LOCKED,
        AVAILABLE,
        COMPLETED
    }

    @FXML
    private VBox secao0;
    @FXML
    private VBox secao1;
    @FXML
    private VBox secao2;
    @FXML
    private VBox secao3;
    @FXML
    private VBox secao4;
    @FXML
    private VBox secao5;
    @FXML
    private VBox secao6;

    @FXML
    private Button btnMarkdown;
    
    @FXML
    private HBox bannerNotificacao;
    
    @FXML
    private Label labelProfessor;
    
    @FXML
    private Label labelMensagens;

    private VBox secaoSelecionada = null;
    private Map<Integer, SectionStatus> sectionStatus = new HashMap<>();
    private List<VBox> sectionVBoxes;
    
    // Dados do usuário logado e professor
    private Usuario alunoLogado;
    private Usuario professorAceito;
    private String emailAluno;
    private String emailProf;

    @FXML
    public void initialize() {
        sectionVBoxes = List.of(secao0, secao1, secao2, secao3, secao4, secao5, secao6);

        // Obtém o aluno logado
        alunoLogado = Sessao.getUsuario();
        if (alunoLogado == null) {
            System.err.println("[ERRO] Nenhum usuário logado!");
            mostrarErro("Erro", "Nenhum usuário logado no sistema.");
            return;
        }

        emailAluno = alunoLogado.getEmail();
        System.out.println("[PERFIL] Aluno logado: " + emailAluno);

        // Carrega o professor aceito pelo aluno
        carregarProfessor();

        // Carrega o progresso das seções do banco de dados
        carregarProgressoSecoes();

        // Atualiza a visualização das seções
        updateSectionViews();

        // Verifica se TODAS as seções (0..6) foram aprovadas
        atualizarVisibilidadeMarkdown();
    }

    /**
     * Carrega o professor aceito pelo aluno do banco de dados
     */
    private void carregarProfessor() {
        try {
            SolicitacaoDAO solicitacaoDAO = new SolicitacaoDAO();
            professorAceito = solicitacaoDAO.obterProfessorAceitoPorAluno(emailAluno);

            if (professorAceito != null) {
                emailProf = professorAceito.getEmail();
                String nomeProfessor = professorAceito.getNome();

                // Atualiza o label com o nome do professor
                Platform.runLater(() -> {
                    // Busca os labels no HBox do banner
                    if (bannerNotificacao != null) {
                        for (Node node : bannerNotificacao.getChildren()) {
                            if (node instanceof VBox) {
                                VBox vbox = (VBox) node;
                                for (Node child : vbox.getChildren()) {
                                    if (child instanceof Label) {
                                        Label label = (Label) child;
                                        if (label.getText().contains("Professor")) {
                                            label.setText(nomeProfessor);
                                        }
                                    }
                                }
                            }
                        }
                    }
                });

                System.out.println("[PERFIL] Professor aceito: " + nomeProfessor + " (" + emailProf + ")");
            } else {
                System.out.println("[PERFIL] Nenhum professor aceito ainda.");
                Platform.runLater(() -> {
                    if (bannerNotificacao != null) {
                        for (Node node : bannerNotificacao.getChildren()) {
                            if (node instanceof VBox) {
                                VBox vbox = (VBox) node;
                                for (Node child : vbox.getChildren()) {
                                    if (child instanceof Label) {
                                        Label label = (Label) child;
                                        if (label.getText().contains("Professor")) {
                                            label.setText("Nenhum professor vinculado");
                                        } else if (label.getText().contains("mensagens")) {
                                            label.setText("Solicite um professor primeiro");
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
        } catch (Exception e) {
            System.err.println("[ERRO] Erro ao carregar professor: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Carrega o progresso das seções do banco de dados
     * Verifica a tabela feedback para ver quais seções foram aprovadas
     */
    private void carregarProgressoSecoes() {
        if (emailProf == null) {
            // Se não tem professor, apenas a seção 0 fica disponível
            sectionStatus.put(0, SectionStatus.AVAILABLE);
            for (int i = 1; i <= 6; i++) {
                sectionStatus.put(i, SectionStatus.LOCKED);
            }
            System.out.println("[PERFIL] Sem professor - apenas Seção 0 disponível");
            return;
        }

        try {
            FeedbackDAO feedbackDAO = new FeedbackDAO();

            // Inicializa todas as seções como bloqueadas
            for (int i = 0; i <= 6; i++) {
                sectionStatus.put(i, SectionStatus.LOCKED);
            }

            // Seção 0 sempre começa disponível
            sectionStatus.put(0, SectionStatus.AVAILABLE);

            // Para cada seção, verifica se existe feedback aprovado
            for (int i = 0; i <= 6; i++) {
                List<FeedbackDAO.FeedbackData> feedbacks = feedbackDAO.carregarFeedbacks(emailAluno, i);

                if (!feedbacks.isEmpty()) {
                    FeedbackDAO.FeedbackData feedback = feedbacks.get(0); // Pega o mais recente

                    if (feedback.statusAprovacao != null) {
                        if (feedback.statusAprovacao == 1) {
                            // Aprovado - marca como completo
                            sectionStatus.put(i, SectionStatus.COMPLETED);

                            // Desbloqueia a próxima seção
                            int proximaSecao = i + 1;
                            if (proximaSecao <= 6) {
                                sectionStatus.put(proximaSecao, SectionStatus.AVAILABLE);
                            }

                            System.out.println("[PERFIL] Seção " + i + " aprovada");
                        } else if (feedback.statusAprovacao == 0) {
                            // Reprovado - mantém disponível para refazer
                            sectionStatus.put(i, SectionStatus.AVAILABLE);
                            System.out.println("[PERFIL] Seção " + i + " reprovada - disponível para refazer");
                        }
                    }
                }
            }

        } catch (SQLException e) {
            System.err.println("[ERRO] Erro ao carregar progresso: " + e.getMessage());
            e.printStackTrace();
            mostrarErro("Erro ao carregar progresso", "Não foi possível carregar o progresso das seções.");
        }
    }

    @FXML
    private void handleSelecionarSecao(MouseEvent event) throws IOException {
        VBox clickedVBox = (VBox) event.getSource();

        String rawId = clickedVBox.getId();
        int sectionIndex = Integer.parseInt(rawId.replace("secao", ""));

        SectionStatus status = sectionStatus.get(sectionIndex);

        if (status == SectionStatus.LOCKED) {
            System.out.println("[PERFIL] Seção " + sectionIndex + " está bloqueada.");

            mostrarAviso("Seção Bloqueada",
                        "Esta seção está bloqueada.\n" +
                        "Complete e aguarde a aprovação da seção anterior para desbloqueá-la.");

            return;
        }

        if (secaoSelecionada != null) {
            secaoSelecionada.getStyleClass().remove("secao-selecionada");
        }
        clickedVBox.getStyleClass().add("secao-selecionada");
        secaoSelecionada = clickedVBox;

        String fxmlPath = null;
        if (sectionIndex == 0) {
            fxmlPath = "/org/example/telacad/Secao0View.fxml";
            trocarCena(event, fxmlPath, 1100, 700);
        } else if (sectionIndex >= 1 && sectionIndex <= 6) {
            fxmlPath = "/org/example/telacad/Secao6View.fxml";
            // ✅ Parâmetros na ordem correta: (event, fxml, numeroSecao, width, height)
            trocarCenaComSecao(event, fxmlPath, sectionIndex, 1100, 700);
        }

        if (fxmlPath == null) {
            if (secaoSelecionada != null) {
                secaoSelecionada.getStyleClass().remove("secao-selecionada");
                secaoSelecionada.getStyleClass().add("secao-padrao");
                secaoSelecionada = null;
            }
        }
    }

    private void updateSectionViews() {
        for (int i = 0; i <= 6; i++) {
            VBox currentVBox = sectionVBoxes.get(i);
            SectionStatus status = sectionStatus.get(i);

            Label label = (Label) currentVBox.lookup(".label");
            if (label == null) {
                continue;
            }

            String newText = "SEÇÃO " + i;
            String styleClass;

            currentVBox.getStyleClass().removeIf(s -> s.startsWith("secao-"));

            switch (status) {
                case LOCKED:
                    newText += " 🔒";
                    styleClass = "secao-locked";
                    break;
                case AVAILABLE:
                    styleClass = "secao-padrao";
                    break;
                case COMPLETED:
                    newText += " ✅";
                    styleClass = "secao-completed";
                    break;
                default:
                    styleClass = "secao-padrao";
            }

            label.setText(newText);
            currentVBox.getStyleClass().add(styleClass);
        }
    }

    /**
     * Desbloqueia a próxima seção após a conclusão da seção atual
     * Este método deve ser chamado pelas telas de seção após o envio
     */
    public void unlockNextSection(int completedSectionIndex) {
        sectionStatus.put(completedSectionIndex, SectionStatus.COMPLETED);

        int nextIndex = completedSectionIndex + 1;
        if (sectionStatus.containsKey(nextIndex)) {
            sectionStatus.put(nextIndex, SectionStatus.AVAILABLE);
        }

        updateSectionViews();
        atualizarVisibilidadeMarkdown();
    }

    /**
     * Recarrega o progresso das seções
     * Útil para atualizar a tela após o professor aprovar/reprovar
     */
    public void recarregarProgresso() {
        carregarProgressoSecoes();
        updateSectionViews();
        atualizarVisibilidadeMarkdown();
    }

    // ================== MARKDOWN ==================

    /**
     * Verifica no banco (tabela feedback) se TODAS as seções 0..6 têm pelo menos
     * um feedback com status_aprovacao = 1. Se sim, mostra o botão Markdown.
     */
    private void atualizarVisibilidadeMarkdown() {
        if (btnMarkdown == null || alunoLogado == null) {
            return;
        }

        boolean todasAprovadas = verificarTodasSecoesAprovadas();

        if (todasAprovadas) {
            btnMarkdown.setVisible(true);
            btnMarkdown.setManaged(true);
        } else {
            btnMarkdown.setVisible(false);
            btnMarkdown.setManaged(false);
        }
    }

    private boolean verificarTodasSecoesAprovadas() {
        try {
            FeedbackDAO dao = new FeedbackDAO();

            // Seções 0 até 6
            for (int sec = 0; sec <= 6; sec++) {
                List<FeedbackDAO.FeedbackData> feedbacks =
                        dao.carregarFeedbacks(emailAluno, sec);

                boolean secaoAprovada = false;

                for (FeedbackDAO.FeedbackData fb : feedbacks) {
                    if (fb.statusAprovacao != null && fb.statusAprovacao == 1) {
                        secaoAprovada = true;
                        break;
                    }
                }

                if (!secaoAprovada) {
                    // Achou alguma seção NÃO aprovada -> já pode retornar false
                    return false;
                }
            }

            // Todas as seções passaram na verificação
            return true;

        } catch (SQLException e) {
            System.err.println("[ERRO] Verificando seções aprovadas para markdown: " + e.getMessage());
            e.printStackTrace();
            return false; // em caso de erro, melhor NÃO liberar o botão
        }
    }

    /**
     * NOVO MÉTODO: Chamado ao clicar no banner do professor.
     */
    @FXML
    private void handleAbrirChat(MouseEvent e) {
        if (professorAceito == null) {
            mostrarAviso("Sem Professor", "Você ainda não tem um professor vinculado.\nSolicite um professor primeiro.");
            return;
        }

        navegarPara("/org/example/telacad/Chat-aluno.fxml", "Chat", (Node) e.getSource());
    }

    @FXML
    private void handleMarkdown(ActionEvent event) {
        System.out.println("[PERFIL] Botão Markdown clicado!");
        // TODO: Implementar navegação para tela de configuração do Markdown
        mostrarInfo("Markdown", "Funcionalidade de configuração do Markdown em desenvolvimento.");
    }

    @FXML
    private void handleEditarPerfil(ActionEvent e) {
        navegarPara("/org/example/telacad/Perfil_Aluno.fxml", "Perfil do Aluno", (Node) e.getSource());
    }

    @FXML
    private void handleAbrirManuais(ActionEvent event) throws IOException {
        abrirModal(event, "/ManuaisView.fxml", true);
    }

    private void abrirModal(ActionEvent event, String fxmlPath, boolean transparente) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Parent root = loader.load();

        Stage modalStage = new Stage();
        modalStage.initModality(Modality.APPLICATION_MODAL);

        if (transparente) {
            modalStage.initStyle(StageStyle.TRANSPARENT);
        } else {
            modalStage.initStyle(StageStyle.UNDECORATED);
        }

        Scene scene = new Scene(root);
        if (transparente) {
            scene.setFill(null);
        }
        modalStage.setScene(scene);

        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        modalStage.setX(primaryStage.getX());
        modalStage.setY(primaryStage.getY());
        modalStage.setWidth(primaryStage.getWidth());
        modalStage.setHeight(primaryStage.getHeight());

        if (loader.getController() instanceof EditarPerfilController) {
            EditarPerfilController controller = loader.getController();
        } else if (loader.getController() instanceof ManuaisController) {
            ManuaisController controller = loader.getController();
            controller.setPerfilController(this);
        }

        modalStage.showAndWait();
    }

    private void trocarCena(MouseEvent event, String fxmlFile, int width, int height) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, width, height);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * NOVO MÉTODO: Troca a cena E passa o número da seção para o controller
     */
    private void trocarCenaComSecao(MouseEvent event, String fxmlFile, int numeroSecao, int width, int height) throws IOException {
        // 1. Criar FXMLLoader (não-estático)
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        
        // 2. Carregar o FXML
        Parent root = loader.load();
        
        // 3. Pegar o controller DEPOIS de carregar
        Object controller = loader.getController();
        
        // 4. Se for Secao6Controller, define o número da seção E inicializa dados
        if (controller instanceof Secao6Controller) {
            Secao6Controller secao6Controller = (Secao6Controller) controller;
            secao6Controller.setNumeroSecao(numeroSecao); // Define qual seção (1-6)
            secao6Controller.inicializarSecao(); // ⭐ INICIALIZA dados DEPOIS de definir numeroSecao
        }
        
        // 5. Trocar a cena
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, width, height);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleVoltar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleSair() {
        System.out.println("[PERFIL] Sair clicado");
    }

    @FXML
    private void voltarParaLogin(ActionEvent e) {
        navegarPara("/org/example/telacad/LoginView.fxml", "Login", (Node) e.getSource());
    }

    private void navegarPara(String fxmlPath, String titulo, Node sourceNode) {
        try {
            Stage stage = (Stage) sourceNode.getScene().getWindow();
            Parent page = FXMLLoader.load(getClass().getResource(fxmlPath));
            Scene scene = new Scene(page);
            stage.setScene(scene);
            stage.setTitle(titulo);
            stage.setMaximized(true);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Métodos auxiliares para mostrar alertas
    private void mostrarErro(String titulo, String mensagem) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(titulo);
            alert.setHeaderText(null);
            alert.setContentText(mensagem);
            alert.showAndWait();
        });
    }

    private void mostrarAviso(String titulo, String mensagem) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle(titulo);
            alert.setHeaderText(null);
            alert.setContentText(mensagem);
            alert.showAndWait();
        });
    }

    private void mostrarInfo(String titulo, String mensagem) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(titulo);
            alert.setHeaderText(null);
            alert.setContentText(mensagem);
            alert.showAndWait();
        });
    }
}
