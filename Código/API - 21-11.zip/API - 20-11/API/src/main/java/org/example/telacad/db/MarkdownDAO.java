package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MarkdownDAO {

    /**
     * Retorna true se TODAS as seções (0 a 6) do aluno estiverem aprovadas.
     *
     * Regra:
     *  - feedback.status_aprovacao = 1 (aprovado)
     *  - numero_secao entre 0 e 6
     *  - conta DISTINCT(numero_secao)
     *  - se tiver 7, tudo aprovado
     *
     * Aqui estou ignorando email_prof porque, na prática, cada aluno só tem 1
     * orientador. Se um dia você tiver mais de um, dá pra acrescentar o filtro
     * por professor.
     */
    public boolean todasSecoesAprovadas(String emailAluno) throws SQLException {
        String sql =
                "SELECT COUNT(DISTINCT numero_secao) AS qtd " +
                "  FROM feedback " +
                " WHERE email_aluno = ? " +
                "   AND status_aprovacao = 1 " +
                "   AND numero_secao BETWEEN 0 AND 6";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailAluno);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int qtd = rs.getInt("qtd");
                    return qtd >= 7;  // 0..6 -> 7 seções aprovadas
                }
            }
        }

        return false;
    }
}
