package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SecaoAPIDAO {

    // Salvar/Atualizar Seção de API (1-6)
    public void salvarSecaoAPI(String emailAluno, String emailProf, int numeroSecao, String empresaParceira,
                               String problema, String solucao, String solucaoImagemPath,
                               String repositorio, String tecnologias, String contribuicoes,
                               String detalhesContribuicoes, String hardSkills, String softSkills) throws SQLException {
        
        String sql = "INSERT INTO secao_api (email_aluno, email_prof, numero_secao, empresa_parceira, problema, " +
                     "solucao, solucao_imagem_path, repositorio_github, tecnologias_utilizadas, " +
                     "contribuicoes_pessoais, detalhes_contribuicoes, hard_skills, soft_skills) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE " +
                     "empresa_parceira = VALUES(empresa_parceira), problema = VALUES(problema), " +
                     "solucao = VALUES(solucao), solucao_imagem_path = VALUES(solucao_imagem_path), " +
                     "repositorio_github = VALUES(repositorio_github), " +
                     "tecnologias_utilizadas = VALUES(tecnologias_utilizadas), " +
                     "contribuicoes_pessoais = VALUES(contribuicoes_pessoais), " +
                     "detalhes_contribuicoes = VALUES(detalhes_contribuicoes), " +
                     "hard_skills = VALUES(hard_skills), soft_skills = VALUES(soft_skills)";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setInt(3, numeroSecao);
            ps.setString(4, empresaParceira);
            ps.setString(5, problema);
            ps.setString(6, solucao);
            ps.setString(7, solucaoImagemPath);
            ps.setString(8, repositorio);
            ps.setString(9, tecnologias);
            ps.setString(10, contribuicoes);
            ps.setString(11, detalhesContribuicoes);
            ps.setString(12, hardSkills);
            ps.setString(13, softSkills);
            ps.executeUpdate();
        }
    }

    // Carregar Seção de API
    public SecaoAPIData carregarSecaoAPI(String emailAluno, int numeroSecao) throws SQLException {
        String sql = "SELECT * FROM secao_api WHERE email_aluno = ? AND numero_secao = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setInt(2, numeroSecao);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new SecaoAPIData(
                        rs.getString("email_aluno"),
                        rs.getInt("numero_secao"),
                        rs.getString("empresa_parceira"),
                        rs.getString("problema"),
                        rs.getString("solucao"),
                        rs.getString("solucao_imagem_path"),
                        rs.getString("repositorio_github"),
                        rs.getString("tecnologias_utilizadas"),
                        rs.getString("contribuicoes_pessoais"),
                        rs.getString("detalhes_contribuicoes"),
                        rs.getString("hard_skills"),
                        rs.getString("soft_skills")
                    );
                }
            }
        }
        return null;
    }

    // Classe interna para armazenar dados
    public static class SecaoAPIData {
        public final String emailAluno, empresaParceira, problema, solucao, solucaoImagemPath;
        public final String repositorio, tecnologias, contribuicoes, detalhesContribuicoes;
        public final String hardSkills, softSkills;
        public final int numeroSecao;

        public SecaoAPIData(String emailAluno, int numeroSecao, String empresaParceira,
                           String problema, String solucao, String solucaoImagemPath,
                           String repositorio, String tecnologias, String contribuicoes,
                           String detalhesContribuicoes, String hardSkills, String softSkills) {
            this.emailAluno = emailAluno;
            this.numeroSecao = numeroSecao;
            this.empresaParceira = empresaParceira;
            this.problema = problema;
            this.solucao = solucao;
            this.solucaoImagemPath = solucaoImagemPath;
            this.repositorio = repositorio;
            this.tecnologias = tecnologias;
            this.contribuicoes = contribuicoes;
            this.detalhesContribuicoes = detalhesContribuicoes;
            this.hardSkills = hardSkills;
            this.softSkills = softSkills;
        }
    }
    public boolean secaoEnviada(String emailAluno, String emailProf, int numeroSecao) throws SQLException {
    String sql = "SELECT 1 FROM secao_api WHERE email_aluno = ? AND numero_secao = ?";
    
    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, emailAluno);
        ps.setInt(2, numeroSecao); 
        try (ResultSet rs = ps.executeQuery()) {
            return rs.next();
        }
    }
}
}
