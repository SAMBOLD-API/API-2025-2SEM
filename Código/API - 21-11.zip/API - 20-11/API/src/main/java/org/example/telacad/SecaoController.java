package org.example.telacad;

import java.io.File;
import java.sql.SQLException;
import java.util.List;

import org.example.telacad.db.FeedbackDAO;
import org.example.telacad.db.Secao0DAO;
import org.example.telacad.db.SecaoAPIDAO;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SecaoController {

    // ---------- LADO ESQUERDO ----------
    @FXML private Label lblNomeAluno;

    @FXML private Button btnSecao0;
    @FXML private Button btnSecao1;
    @FXML private Button btnSecao2;
    @FXML private Button btnSecao3;
    @FXML private Button btnSecao4;
    @FXML private Button btnSecao5;
    @FXML private Button btnSecao6;

    // ---------- ÁREA CENTRAL ----------
    @FXML private GridPane formSecao0;
    @FXML private GridPane formSecaoAPI;
    @FXML private Label    lblDefaultContent;

    // ---------- CAMPOS DA SEÇÃO 0 ----------
    @FXML private ImageView imgFotoSecao0;

    @FXML private TextField txtNomeCompletoS0;
    @FXML private TextField txtIdadeS0;
    @FXML private TextField txtCursoS0;
    @FXML private TextField txtEmailS0;
    @FXML private TextField txtLinkedInS0;
    @FXML private TextField txtGitHubS0;

    @FXML private TextArea txtMotivacaoS0;
    @FXML private TextArea txtHistAcademicoS0;
    @FXML private TextArea txtHistProfissionalS0;
    @FXML private TextArea txtConhecimentosS0;

    // ---------- CAMPOS SEÇÕES 1–6 ----------
    @FXML private Label     lblTituloSecaoAPI;
    @FXML private ImageView imgSolucaoAPI;

    @FXML private TextField txtEmpresaParceiraAPI;
    @FXML private TextArea  txtProblemaAPI;
    @FXML private TextArea  txtSolucaoAPI;
    @FXML private TextField txtRepositorioAPI;
    @FXML private TextArea  txtTecnologiasAPI;
    @FXML private TextArea  txtContribuicoesAPI;
    @FXML private TextArea  txtDetalhesContribuicoesAPI;
    @FXML private TextArea  txtHardSkillsAPI;
    @FXML private TextArea  txtSoftSkillsAPI;

    // ---------- FEEDBACK ----------
    @FXML private VBox              vboxListaFeedbackS0;
    @FXML private ChoiceBox<String> choiceFeedbackS0;
    @FXML private TextField         txtEnviarFeedbackS0;
    @FXML private Button            btnAprovarS0;
    @FXML private Button            btnReprovarS0;

    // contexto
    private String emailAluno;
    private String nomeAluno;
    private String emailProfessor;
    private int    secaoAtual = 0;  // 0..6

    private final Secao0DAO   secao0DAO   = new Secao0DAO();
    private final FeedbackDAO feedbackDAO = new FeedbackDAO();
    private final SecaoAPIDAO secaoAPIDAO = new SecaoAPIDAO();

    // ================== SETTERS CHAMADOS PELO HomePController ==================

    public void setEmailAluno(String emailAluno) {
        this.emailAluno = emailAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
        if (lblNomeAluno != null) {
            lblNomeAluno.setText(nomeAluno);
        }
    }

    public void setEmailProfessor(String emailProfessor) {
        this.emailProfessor = emailProfessor;
    }

    public void inicializarTela() {
        try {
            if (nomeAluno != null && lblNomeAluno != null) {
                lblNomeAluno.setText(nomeAluno);
            }

            secaoAtual = 0;
            mostrarApenasSecao0();
            atualizarEstiloBotoes(0);

            carregarDadosSecao0();
            carregarFeedbacksSecao(secaoAtual);
            configurarBotoesSecao();
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Erro ao carregar dados da seção: " + e.getMessage());
        }
    }

    // ================== SEÇÃO 0 ==================

    private void carregarDadosSecao0() throws SQLException {
        if (emailAluno == null) return;

        Secao0DAO.Secao0Data dados = secao0DAO.carregarSecao0(emailAluno);
        if (dados == null) {
            mostrarAlerta("Aviso", "O aluno ainda não preencheu a Seção 0.");
            return;
        }

        setText(txtNomeCompletoS0, dados.nomeCompleto);
        setText(txtIdadeS0, dados.idade != 0 ? String.valueOf(dados.idade) : "");
        setText(txtCursoS0, dados.curso);
        setText(txtEmailS0, dados.emailContato);
        setText(txtLinkedInS0, dados.linkedin);
        setText(txtGitHubS0, dados.github);
        setText(txtMotivacaoS0, dados.motivacao);
        setText(txtHistAcademicoS0, dados.histAcademico);
        setText(txtHistProfissionalS0, dados.histProfissional);
        setText(txtConhecimentosS0, dados.conhecimentos);

        if (dados.fotoPath != null && !dados.fotoPath.trim().isEmpty()) {
            carregarImagem(imgFotoSecao0, dados.fotoPath);
        }
    }

    // ================== SEÇÕES 1–6 ==================

    private void carregarDadosSecaoAPI(int numeroSecao) throws SQLException {
        if (emailAluno == null) return;

        SecaoAPIDAO.SecaoAPIData dados = secaoAPIDAO.carregarSecaoAPI(emailAluno, numeroSecao);
        if (dados == null) {
            limparCamposAPI();
            setText(txtProblemaAPI, "Seção " + numeroSecao + " ainda não foi preenchida pelo aluno.");
            return;
        }

        setText(txtEmpresaParceiraAPI, dados.empresaParceira);
        setText(txtProblemaAPI, dados.problema);
        setText(txtSolucaoAPI, dados.solucao);
        setText(txtRepositorioAPI, dados.repositorio);
        setText(txtTecnologiasAPI, dados.tecnologias);
        setText(txtContribuicoesAPI, dados.contribuicoes);
        setText(txtDetalhesContribuicoesAPI, dados.detalhesContribuicoes);
        setText(txtHardSkillsAPI, dados.hardSkills);
        setText(txtSoftSkillsAPI, dados.softSkills);

        if (dados.solucaoImagemPath != null && !dados.solucaoImagemPath.trim().isEmpty()) {
            carregarImagem(imgSolucaoAPI, dados.solucaoImagemPath);
        } else if (imgSolucaoAPI != null) {
            imgSolucaoAPI.setImage(null);
        }
    }

    private void limparCamposAPI() {
        setText(txtEmpresaParceiraAPI, "");
        setText(txtProblemaAPI, "");
        setText(txtSolucaoAPI, "");
        setText(txtRepositorioAPI, "");
        setText(txtTecnologiasAPI, "");
        setText(txtContribuicoesAPI, "");
        setText(txtDetalhesContribuicoesAPI, "");
        setText(txtHardSkillsAPI, "");
        setText(txtSoftSkillsAPI, "");
        if (imgSolucaoAPI != null) {
            imgSolucaoAPI.setImage(null);
        }
    }

    private void carregarFeedbacksSecao(int numeroSecao) {
        if (vboxListaFeedbackS0 == null || emailAluno == null) return;

        try {
            vboxListaFeedbackS0.getChildren().clear();

            List<FeedbackDAO.FeedbackData> feedbacks =
                    feedbackDAO.carregarFeedbacks(emailAluno, numeroSecao);

            for (FeedbackDAO.FeedbackData fb : feedbacks) {
                if (fb.comentario == null || fb.comentario.trim().isEmpty()) continue;

                Label lbl = new Label(fb.comentario);
                lbl.setWrapText(true);
                lbl.getStyleClass().add("feedback-item");
                vboxListaFeedbackS0.getChildren().add(lbl);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================== BOTÕES DE SEÇÃO ==================

    private void configurarBotoesSecao() {
        if (btnSecao0 != null) btnSecao0.setDisable(false);

        if (emailAluno == null) return;

        try {
            for (int i = 1; i <= 6; i++) {
                Button b = getButtonByNumero(i);
                if (b == null) continue;

                boolean enviada = secaoAPIDAO.secaoEnviada(emailAluno, emailProfessor, i);
                b.setDisable(!enviada);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Button getButtonByNumero(int numero) {
        switch (numero) {
            case 0: return btnSecao0;
            case 1: return btnSecao1;
            case 2: return btnSecao2;
            case 3: return btnSecao3;
            case 4: return btnSecao4;
            case 5: return btnSecao5;
            case 6: return btnSecao6;
            default: return null;
        }
    }

    private void esconderTodosFormularios() {
        if (lblDefaultContent != null) lblDefaultContent.setVisible(false);
        if (formSecao0 != null) formSecao0.setVisible(false);
        if (formSecaoAPI != null) formSecaoAPI.setVisible(false);
    }

    private void mostrarApenasSecao0() {
        esconderTodosFormularios();
        if (formSecao0 != null) formSecao0.setVisible(true);
    }

    private void atualizarEstiloBotoes(int numeroSecao) {
        Button[] botoes = { btnSecao0, btnSecao1, btnSecao2,
                            btnSecao3, btnSecao4, btnSecao5, btnSecao6 };

        for (int i = 0; i < botoes.length; i++) {
            Button b = botoes[i];
            if (b == null) continue;

            b.getStyleClass().remove("sidebar-button-active");
            if (i == numeroSecao && !b.getStyleClass().contains("sidebar-button-active")) {
                b.getStyleClass().add("sidebar-button-active");
            }
        }
    }

    private void abrirSecao(int numeroSecao) {
        if (emailAluno == null) {
            mostrarAlerta("Aviso", "Dados de contexto não carregados (aluno/professor).");
            return;
        }

        Button botao = getButtonByNumero(numeroSecao);
        if (botao == null || botao.isDisable()) {
            mostrarAlerta("Seção bloqueada", "Essa seção ainda não foi enviada pelo aluno.");
            return;
        }

        secaoAtual = numeroSecao;
        atualizarEstiloBotoes(numeroSecao);
        esconderTodosFormularios();

        try {
            if (numeroSecao == 0) {
                if (formSecao0 != null) formSecao0.setVisible(true);
                carregarDadosSecao0();
            } else {
                if (formSecaoAPI != null) formSecaoAPI.setVisible(true);
                if (lblTituloSecaoAPI != null) {
                    lblTituloSecaoAPI.setText("Conteúdo da Seção " + numeroSecao);
                }
                carregarDadosSecaoAPI(numeroSecao);
            }

            carregarFeedbacksSecao(secaoAtual);

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Erro ao carregar dados da Seção " + numeroSecao + ": " + e.getMessage());
        }
    }

    @FXML private void abrirSecao0(ActionEvent event) { abrirSecao(0); }
    @FXML private void abrirSecao1(ActionEvent event) { abrirSecao(1); }
    @FXML private void abrirSecao2(ActionEvent event) { abrirSecao(2); }
    @FXML private void abrirSecao3(ActionEvent event) { abrirSecao(3); }
    @FXML private void abrirSecao4(ActionEvent event) { abrirSecao(4); }
    @FXML private void abrirSecao5(ActionEvent event) { abrirSecao(5); }
    @FXML private void abrirSecao6(ActionEvent event) { abrirSecao(6); }

    // ================== FEEDBACK ==================

    @FXML
    private void handleEnviarFeedback(ActionEvent e) {
        alterarStatusSecao(null);   // só comentário
    }

    @FXML
    private void handleAprovar(ActionEvent e) {
        alterarStatusSecao((byte) 1);
    }

    @FXML
    private void handleReprovar(ActionEvent e) {
        alterarStatusSecao((byte) 0);
    }

    private void alterarStatusSecao(Byte status) {
        if (emailAluno == null || emailProfessor == null) {
            mostrarAlerta("Erro", "Aluno ou professor não carregados na tela.");
            return;
        }

        try {
            String comentario = "";
            if (txtEnviarFeedbackS0 != null && txtEnviarFeedbackS0.getText() != null) {
                comentario = txtEnviarFeedbackS0.getText().trim();
            }

            Integer statusInt = (status == null ? null : status.intValue());

            // sempre grava um novo registro com o comentário (e status, se tiver)
            feedbackDAO.salvarFeedback(
                    emailAluno,
                    emailProfessor,
                    secaoAtual,
                    comentario,
                    statusInt
            );

            // se for aprovar/reprovar, atualiza status da seção
            if (status != null) {
                boolean aprovado = (status == 1);
                feedbackDAO.avaliarSecao(emailAluno, emailProfessor, secaoAtual, aprovado);
            }

            String msg;
            if (status == null) {
                msg = "Feedback enviado com sucesso!";
            } else if (status == 1) {
                msg = "Seção " + secaoAtual + " aprovada com sucesso!";
            } else {
                msg = "Seção " + secaoAtual + " reprovada. O aluno poderá reenviar.";
            }
            mostrarInfo("Sucesso", msg);

            if (txtEnviarFeedbackS0 != null) {
                txtEnviarFeedbackS0.clear();
            }
            carregarFeedbacksSecao(secaoAtual);

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Erro ao atualizar status da seção: " + e.getMessage());
        }
    }

    // ================== VOLTAR (BOTÃO X) ==================

    @FXML
    private void handleVoltarParaHome(ActionEvent event) {
        // você já tem o HomeP aberto atrás, então aqui é só FECHAR essa janela
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        stage.close();
    }

    // ================== AUXILIARES ==================

    private void carregarImagem(ImageView imageView, String path) {
        if (imageView == null || path == null || path.isEmpty()) return;

        try {
            File file = new File(path);
            if (!file.exists()) {
                System.err.println("Imagem não encontrada: " + path);
                return;
            }

            Image image = new Image(file.toURI().toString(), false);

            imageView.setPreserveRatio(true);
            imageView.setSmooth(true);
            imageView.setFitWidth(210);
            imageView.setFitHeight(170);

            imageView.setImage(image);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setText(TextField field, String text) {
        if (field != null) field.setText(text != null ? text : "");
    }

    private void setText(TextArea field, String text) {
        if (field != null) field.setText(text != null ? text : "");
    }

    private void mostrarAlerta(String titulo, String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void mostrarInfo(String titulo, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
