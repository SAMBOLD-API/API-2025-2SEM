package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {

    // === Salvar NOVO feedback (não sobrescreve) ===
    public void salvarFeedback(String emailAluno, String emailProf, int numeroSecao,
                               String comentario, Integer statusAprovacao) throws SQLException {

        String sql = "INSERT INTO feedback " +
                     "(email_aluno, email_prof, numero_secao, comentario, status_aprovacao) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setInt(3, numeroSecao);
            ps.setString(4, comentario);

            if (statusAprovacao == null) {
                ps.setNull(5, Types.TINYINT);
            } else {
                ps.setInt(5, statusAprovacao);
            }

            ps.executeUpdate();
        }
    }

    // === Carregar TODOS os feedbacks de uma seção ===
    public List<FeedbackData> carregarFeedbacks(String emailAluno, int numeroSecao) throws SQLException {
        String sql = "SELECT * " +
                     "FROM feedback " +
                     "WHERE email_aluno = ? AND numero_secao = ? " +
                     "ORDER BY created_at DESC";

        List<FeedbackData> feedbacks = new ArrayList<>();

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailAluno);
            ps.setInt(2, numeroSecao);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    feedbacks.add(new FeedbackData(
                        rs.getInt("id"),
                        rs.getString("email_aluno"),
                        rs.getString("email_prof"),
                        rs.getInt("numero_secao"),
                        rs.getString("comentario"),
                        rs.getObject("status_aprovacao") != null ? rs.getInt("status_aprovacao") : null,
                        rs.getTimestamp("created_at")
                    ));
                }
            }
        }
        return feedbacks;
    }

    // === Aprovar / Reprovar seção (status da seção) ===
    public void avaliarSecao(String emailAluno, String emailProf, int numeroSecao, boolean aprovado) throws SQLException {
        String sql = "UPDATE feedback SET status_aprovacao = ? " +
                     "WHERE email_aluno = ? AND email_prof = ? AND numero_secao = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, aprovado ? 1 : 0);
            ps.setString(2, emailAluno);
            ps.setString(3, emailProf);
            ps.setInt(4, numeroSecao);

            ps.executeUpdate();
        }
    }

    // === Classe interna de dados ===
    public static class FeedbackData {
        public final int id, numeroSecao;
        public final String emailAluno, emailProf, comentario;
        public final Integer statusAprovacao;
        public final Timestamp createdAt;

        public FeedbackData(int id, String emailAluno, String emailProf, int numeroSecao,
                            String comentario, Integer statusAprovacao, Timestamp createdAt) {
            this.id = id;
            this.emailAluno = emailAluno;
            this.emailProf = emailProf;
            this.numeroSecao = numeroSecao;
            this.comentario = comentario;
            this.statusAprovacao = statusAprovacao;
            this.createdAt = createdAt;
        }
    }

    // === Status de aprovação da seção (pega o último registro) ===
    public Integer getStatusAprovacao(String emailAluno, String emailProf, int numeroSecao) throws SQLException {
        String sql = "SELECT status_aprovacao " +
                     "FROM feedback " +
                     "WHERE email_aluno = ? AND email_prof = ? AND numero_secao = ? " +
                     "ORDER BY created_at DESC " +
                     "LIMIT 1";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setInt(3, numeroSecao);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Object value = rs.getObject("status_aprovacao");
                    return value != null ? rs.getInt("status_aprovacao") : null;
                }
            }
        }
        return null;
    }

    // (opcional) criar registro inicial vazio se quiser
    public void criarFeedbackInicial(String emailAluno, String emailProf, int numeroSecao) throws SQLException {
        String sql = "INSERT INTO feedback " +
                     "(email_aluno, email_prof, numero_secao, comentario, status_aprovacao) " +
                     "VALUES (?, ?, ?, ?, NULL)";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setInt(3, numeroSecao);
            ps.setString(4, "");

            ps.executeUpdate();
        }
    }
}
