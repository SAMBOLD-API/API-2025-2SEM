package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.example.telacad.models.Solicitacao;
import org.example.telacad.models.Usuario;

public class SolicitacaoDAO {

    // Verifica se o aluno tem alguma solicitação ativa (pendente ou aceita)
    public Solicitacao buscarSolicitacaoAtiva(String emailAluno) throws SQLException {
        String sql = "SELECT email_aluno, email_prof, _status FROM solicitacao " +
                     "WHERE email_aluno = ? AND (_status = 1 OR _status = 2)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Solicitacao s = new Solicitacao();
                    s.setEmailAluno(rs.getString("email_aluno"));
                    s.setEmailProf(rs.getString("email_prof"));
                    s.setStatus(rs.getInt("_status"));
                    return s;
                }
            }
        }
        return null;

    }


    public void atualizarStatusUsuario(String email, int novoStatus) throws SQLException {
        String sql = "UPDATE usuario SET _status = ? WHERE email = ?";
        try (Connection conn = Database.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, novoStatus);
            ps.setString(2, email);
            ps.executeUpdate();
        }
    }

   public void criarSolicitacao(String emailAluno, String emailProf, int status) throws SQLException {
        // upsert: se já existir a dupla, só atualiza status e timestamp
        String sql = "INSERT INTO solicitacao (email_aluno, email_prof, _status) " +
                    "VALUES (?,?,?) " +
                    "ON DUPLICATE KEY UPDATE _status = VALUES(_status), data = CURRENT_TIMESTAMP";
        try (var conn = Database.getConnection();
            var ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setInt(3, status);
            ps.executeUpdate();
        }
    }


    // Busca todas as solicitações pendentes para um professor
    public List<Solicitacao> listarSolicitacoesPendentes(String emailProf) throws SQLException {
        List<Solicitacao> lista = new ArrayList<>();
        String sql = "SELECT s.email_aluno, s.email_prof, s._status, u.nome " +
                     "FROM solicitacao s " +
                     "INNER JOIN usuario u ON s.email_aluno = u.email " +
                     "WHERE s.email_prof = ? AND s._status = 1";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailProf);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Solicitacao s = new Solicitacao();
                    s.setEmailAluno(rs.getString("email_aluno"));
                    s.setEmailProf(rs.getString("email_prof"));
                    s.setStatus(rs.getInt("_status"));
                    s.setNomeAluno(rs.getString("nome"));
                    lista.add(s);
                }
            }
        }
        return lista;
    }

    // Atualiza o status de uma solicitação (aprovar = 2, recusar = 3)
    public void atualizarStatus(String emailAluno, String emailProf, int novoStatus) throws SQLException {
        // Primeiro remove solicitações antigas com status diferente
        String sqlDelete = "DELETE FROM solicitacao WHERE email_aluno = ? AND email_prof = ?";
        // Depois insere a nova solicitação com o status atualizado
        String sqlInsert = "INSERT INTO solicitacao (email_aluno, email_prof, _status) VALUES (?, ?, ?)";
        
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Remove registros antigos
                try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {
                    psDelete.setString(1, emailAluno);
                    psDelete.setString(2, emailProf);
                    psDelete.executeUpdate();
                }
                
                // Insere novo registro com status atualizado
                try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                    psInsert.setString(1, emailAluno);
                    psInsert.setString(2, emailProf);
                    psInsert.setInt(3, novoStatus);
                    psInsert.executeUpdate();
                }
                
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // Lista professores disponíveis para o aluno (mesmo curso exato)
    public List<Usuario> listarProfessoresDisponiveis(String cursoAluno) throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        // Busca professores (perfil 2 ou 3) com curso exatamente igual
        String sql = "SELECT email, nome, curso, perfil FROM usuario " +
                     "WHERE (perfil = 2 OR perfil = 3) AND _status = 1 " +
                     "AND curso = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cursoAluno);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Usuario u = new Usuario(
                        rs.getString("email"),
                        rs.getString("nome"),
                        rs.getString("curso"),
                        "", // senha não é necessária aqui
                        rs.getInt("perfil"),
                        1
                    );
                    lista.add(u);
                }
            }
        }
        return lista;
    }

    // Lista alunos aceitos por um professor
    public List<Usuario> listarAlunosAceitos(String emailProf) throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.email, u.nome, u.curso, u.perfil FROM usuario u " +
                     "INNER JOIN solicitacao s ON u.email = s.email_aluno " +
                     "WHERE s.email_prof = ? AND s._status = 2";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailProf);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Usuario u = new Usuario(
                        rs.getString("email"),
                        rs.getString("nome"),
                        rs.getString("curso"),
                        "",
                        rs.getInt("perfil"),
                        1
                    );
                    lista.add(u);
                }
            }
        }
        return lista;
    }

    public Usuario obterProfessorAceitoPorAluno(String emailAluno) throws Exception {
    String sql =
        "SELECT s.email_prof, u.nome " +  // ✅ Corrigido: email_prof
        "FROM solicitacao s " +
        "LEFT JOIN usuario u ON u.email = s.email_prof " + // ✅ Corrigido
        "WHERE s.email_aluno = ? AND s._status = 2 " + // ✅ Corrigido: _status
        "ORDER BY s.data DESC LIMIT 1"; // ✅ Melhor usar 'data' se tiver

    try (Connection c = Database.getConnection();
         PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setString(1, emailAluno);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String emailProf = rs.getString("email_prof"); // ✅ Corrigido
                String nomeProf  = rs.getString("nome");
                return new Usuario(emailProf, nomeProf, "", "", 2, 1);
            }
            return null;
        }
    }
}


    // Buscar email do professor orientador aceito
    public String buscarProfessorOrientador(String emailAluno) throws SQLException {
        String sql = "SELECT email_prof FROM solicitacao " +
                     "WHERE email_aluno = ? AND _status = 2 " +
                     "ORDER BY data DESC LIMIT 1";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("email_prof");
                }
            }
        }
        return null;
    } 
}
