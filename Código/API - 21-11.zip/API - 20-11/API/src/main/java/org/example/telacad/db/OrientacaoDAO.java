package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrientacaoDAO {

    public static class AlunoOrientado {
        private final String nome;
        private final String email;
        private final boolean hasSecao0;   // se existe registro em secao_0
        private final int qtdSecaoApi;     // quantas seções 1..6 tem na secao_api

        public AlunoOrientado(String nome, String email, boolean hasSecao0, int qtdSecaoApi) {
            this.nome = nome;
            this.email = email;
            this.hasSecao0 = hasSecao0;
            this.qtdSecaoApi = qtdSecaoApi;
        }

        public String getNome() {
            return nome;
        }

        public String getEmail() {
            return email;
        }

        public boolean isHasSecao0() {
            return hasSecao0;
        }

        public int getQtdSecaoApi() {
            return qtdSecaoApi;
        }

        public int getQtdTotalSecoes() {
            // seção 0 + seções 1..6
            return (hasSecao0 ? 1 : 0) + qtdSecaoApi;
        }
    }

    /**
     * Lista todos os alunos que têm solicitação para o professor informado,
     * trazendo:
     *  - se existe secao_0
     *  - quantas seções 1..6 existem na secao_api
     *
     * Tabelas:
     *  - solicitacao(email_aluno, email_prof, _status, ...)
     *  - usuario(email, nome, ...)
     *  - secao_0(email_aluno, email_prof, ...)
     *  - secao_api(email_aluno, email_prof, numero_secao, ...)
     */
    public List<AlunoOrientado> listarAlunosOrientados(String emailProf) throws SQLException {
        List<AlunoOrientado> lista = new ArrayList<>();

        String sql =
                "SELECT s.email_aluno, u.nome, u.email, " +
                "       CASE WHEN s0.email_aluno IS NULL THEN 0 ELSE 1 END AS has_secao0, " +
                "       COALESCE(COUNT(DISTINCT sa.numero_secao), 0) AS qtd_secao_api " +
                "  FROM solicitacao s " +
                "  JOIN usuario u " +
                "       ON u.email = s.email_aluno " +
                "  LEFT JOIN secao_0 s0 " +
                "       ON s0.email_aluno = s.email_aluno " +
                "      AND s0.email_prof  = s.email_prof " +
                "  LEFT JOIN secao_api sa " +
                "       ON sa.email_aluno = s.email_aluno " +
                "      AND sa.email_prof  = s.email_prof " +
                " WHERE s.email_prof = ? " +
                // Se quiser considerar só aprovados, depois troca por:
                // "   AND s._status = 1 " +
                " GROUP BY s.email_aluno, u.nome, u.email, s0.email_aluno " +
                " ORDER BY u.nome";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailProf);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String nome = rs.getString("nome");
                    String email = rs.getString("email");
                    boolean hasSecao0 = rs.getInt("has_secao0") == 1;
                    int qtdSecaoApi = rs.getInt("qtd_secao_api");

                    lista.add(new AlunoOrientado(nome, email, hasSecao0, qtdSecaoApi));
                }
            }
        }

        System.out.println("OrientacaoDAO.listarAlunosOrientados - prof = " +
                emailProf + ", alunos encontrados = " + lista.size());

        return lista;
    }
}
