package org.example.telacad;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class PopupConfirmarController6 {

    private Secao6Controller secaoController;

    public void setSecaoController(Secao6Controller controller) {
        this.secaoController = controller;
    }

    @FXML
    private void handleConfirmarSim(ActionEvent event) throws IOException {
        if (secaoController != null) {
            secaoController.confirmarEnvio();
        }
        closePopup(event);
    }

    @FXML
    private void handleFechar(ActionEvent event) {
        closePopup(event);
    }

    private void closePopup(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
