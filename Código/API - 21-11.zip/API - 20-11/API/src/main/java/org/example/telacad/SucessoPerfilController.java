package org.example.telacad;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class SucessoPerfilController {

    private EditarPerfilController perfilController;

    public void setPerfilController(EditarPerfilController controller) {
        this.perfilController = controller;
    }

    @FXML
    private void handleFechar(ActionEvent event) {
        perfilController.fecharPopup(event);
    }
}
