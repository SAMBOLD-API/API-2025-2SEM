package org.example.telacad.models;

import java.time.LocalDateTime;

public class Documento {
    private int id;
    private String emailAluno;
    private String emailProf;
    private String nomeArquivo;
    private String caminhoArquivo;
    private long tamanhoBytes;
    private String tipoArquivo;
    private LocalDateTime dataUpload;

    public Documento(int id, String emailAluno, String emailProf, String nomeArquivo, String caminhoArquivo, long tamanhoBytes, String tipoArquivo, LocalDateTime dataUpload) {
        this.id = id;
        this.emailAluno = emailAluno;
        this.emailProf = emailProf;
        this.nomeArquivo = nomeArquivo;
        this.caminhoArquivo = caminhoArquivo;
        this.tamanhoBytes = tamanhoBytes;
        this.tipoArquivo = tipoArquivo;
        this.dataUpload = dataUpload;
    }

    // Getters
    public int getId() { return id; }
    public String getEmailAluno() { return emailAluno; }
    public String getEmailProf() { return emailProf; }
    public String getNomeArquivo() { return nomeArquivo; }
    public String getCaminhoArquivo() { return caminhoArquivo; }
    public long getTamanhoBytes() { return tamanhoBytes; }
    public String getTipoArquivo() { return tipoArquivo; }
    public LocalDateTime getDataUpload() { return dataUpload; }
    
    // Método auxiliar para formatar tamanho
    public String getTamanhoFormatado() {
        if (tamanhoBytes < 1024) return tamanhoBytes + " B";
        else if (tamanhoBytes < 1024 * 1024) return String.format("%.2f KB", tamanhoBytes / 1024.0);
        else return String.format("%.2f MB", tamanhoBytes / (1024.0 * 1024.0));
    }
}