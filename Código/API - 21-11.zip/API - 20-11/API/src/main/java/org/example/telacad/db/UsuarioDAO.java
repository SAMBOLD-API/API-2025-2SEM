package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import org.example.telacad.models.Usuario;

public class UsuarioDAO {

    // Login simples
    public Usuario validarLogin(String email, String senhaEmTexto) throws SQLException {
        String sql = "SELECT email, nome, curso, senha, perfil, _status " +
                     "FROM usuario WHERE email = ? AND senha = ? AND _status = 1";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, senhaEmTexto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getString("email"),
                            rs.getString("nome"),
                            rs.getString("curso"),
                            rs.getString("senha"),
                            rs.getInt("perfil"),
                            rs.getInt("_status")
                    );
                }
            }
        }
        return null;
    }

    public boolean emailExiste(String email) throws SQLException {
        String sql = "SELECT 1 FROM usuario WHERE email = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void inserirUsuario(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuario (email, nome, curso, senha, perfil, _status) VALUES (?,?,?,?,?,?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getEmail());
            ps.setString(2, u.getNome());
            ps.setString(3, u.getCurso());
            ps.setString(4, u.getSenha());
            ps.setInt(5, u.getPerfil());
            ps.setInt(6, u.getStatus());
            ps.executeUpdate();
        }
    }

    public void cadastrarAlunoBasico(String email, String nome, String curso, String senhaEmTexto) throws SQLException {
        if (email == null || email.isBlank()) throw new IllegalArgumentException("email obrigatório");
        if (nome == null || nome.isBlank()) throw new IllegalArgumentException("nome obrigatório");
        if (senhaEmTexto == null || senhaEmTexto.isBlank()) throw new IllegalArgumentException("senha obrigatória");

        if (emailExiste(email)) {
            throw new SQLIntegrityConstraintViolationException("Email já cadastrado: " + email);
        }

        String sql = "INSERT INTO usuario (email, nome, curso, senha, perfil, _status) VALUES (?,?,?,?,1,1)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email.trim());
            ps.setString(2, nome.trim());
            ps.setString(3, (curso == null ? "" : curso.trim()));
            ps.setString(4, senhaEmTexto);
            ps.executeUpdate();
        }
    }

    public Usuario buscarPorEmail(String email) throws SQLException {
        String sql = "SELECT email, nome, curso, senha, perfil, _status FROM usuario WHERE email = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getString("email"),
                            rs.getString("nome"),
                            rs.getString("curso"),
                            rs.getString("senha"),
                            rs.getInt("perfil"),
                            rs.getInt("_status")
                    );
                }
            }
        }
        return null;
    }

    public void cadastrarProfessor(String email, String nome, String curso, String senhaEmTexto) throws SQLException {
        if (email == null || email.isBlank()) throw new IllegalArgumentException("Email obrigatório");
        if (nome == null || nome.isBlank()) throw new IllegalArgumentException("Nome obrigatório");
        if (senhaEmTexto == null || senhaEmTexto.isBlank()) throw new IllegalArgumentException("Senha obrigatória");

        if (emailExiste(email)) {
            throw new SQLIntegrityConstraintViolationException("Email já cadastrado: " + email);
        }

        String sql = "INSERT INTO usuario (email, nome, curso, senha, perfil, _status) VALUES (?,?,?,?,2,1)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email.trim());
            ps.setString(2, nome.trim());
            ps.setString(3, (curso == null ? "" : curso.trim()));
            ps.setString(4, senhaEmTexto);
            ps.executeUpdate();
        }
    }

    // Listar todos os professores (perfil 2)
    public List<Usuario> listarProfessores() throws SQLException {
        List<Usuario> professores = new ArrayList<>();
        String sql = "SELECT email, nome, curso, perfil, _status FROM usuario WHERE perfil = 2 ORDER BY nome";

        System.out.println("[DAO] Executando query: " + sql);

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("[DAO] Query executada com sucesso");

            while (rs.next()) {
                String email = rs.getString("email");
                String nome = rs.getString("nome");
                String curso = rs.getString("curso");
                int perfil = rs.getInt("perfil");
                int status = rs.getInt("_status");

                System.out.println("[DAO] Professor encontrado: " + nome + " (" + email + ")");

                Usuario u = new Usuario(email, nome, curso, "", perfil, status);
                professores.add(u);
            }

            System.out.println("[DAO] Total de professores: " + professores.size());
        } catch (SQLException e) {
            System.err.println("[DAO ERRO] Falha ao buscar professores: " + e.getMessage());
            throw e;
        }

        return professores;
    }

    public void atualizarUsuario(String emailAntigo, String emailNovo, String nome, String curso, String novaSenha) throws SQLException {
        if (emailNovo == null || emailNovo.isBlank()) throw new IllegalArgumentException("Email obrigatório");
        if (nome == null || nome.isBlank()) throw new IllegalArgumentException("Nome obrigatório");

        // Se mudou o email, verifica se o novo já existe
        if (!emailAntigo.equals(emailNovo) && emailExiste(emailNovo)) {
            throw new SQLIntegrityConstraintViolationException("Email já cadastrado: " + emailNovo);
        }

        String sql;

        if (novaSenha != null && !novaSenha.isBlank()) {
            sql = "UPDATE usuario SET email = ?, nome = ?, curso = ?, senha = ? WHERE email = ?";
        } else {
            sql = "UPDATE usuario SET email = ?, nome = ?, curso = ? WHERE email = ?";
        }

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, emailNovo.trim());
            ps.setString(2, nome.trim());
            ps.setString(3, (curso == null ? "" : curso.trim()));

            if (novaSenha != null && !novaSenha.isBlank()) {
                ps.setString(4, novaSenha);
                ps.setString(5, emailAntigo);
            } else {
                ps.setString(4, emailAntigo);
            }

            int rows = ps.executeUpdate();

            if (rows == 0) {
                throw new SQLException("Usuário não encontrado: " + emailAntigo);
            }

            System.out.println("[DAO] Usuário atualizado: " + emailNovo);
        }
    }

    // === NOVO MÉTODO: usado na linha 295 do VizualizarProfessorController ===
    public void atualizarStatusUsuario(String email, int novoStatus) throws SQLException {
        String sql = "UPDATE usuario SET _status = ? WHERE email = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, novoStatus);
            ps.setString(2, email);

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Usuário não encontrado para atualizar status: " + email);
            }

            System.out.println("[DAO] Status atualizado para " + novoStatus + " do usuário: " + email);
        }
    }
}
