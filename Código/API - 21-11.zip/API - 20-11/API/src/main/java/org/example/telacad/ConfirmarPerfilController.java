package org.example.telacad;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import java.io.IOException;

public class ConfirmarPerfilController {

    private EditarPerfilController perfilController;

    public void setPerfilController(EditarPerfilController controller) {
        this.perfilController = controller;
    }

    @FXML
    private void handleConfirmarSim(ActionEvent event) throws IOException {
        perfilController.fecharPopup(event);
        perfilController.confirmarAtualizacao();
    }

    @FXML
    private void handleFechar(ActionEvent event) {
        perfilController.fecharPopup(event);
    }
}
