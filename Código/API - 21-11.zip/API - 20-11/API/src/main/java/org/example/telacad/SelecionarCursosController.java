package org.example.telacad;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.util.stream.Collectors;

public class SelecionarCursosController {

    @FXML
    private VBox listaCursosContainer;
    @FXML
    private ScrollPane scrollPane;

    private EditarPerfilController perfilController;

    public void setPerfilController(EditarPerfilController controller) {
        this.perfilController = controller;
    }

    @FXML
    private void handleConfirmarSelecao(ActionEvent event) {
        String cursosSelecionados = listaCursosContainer.getChildren().stream()
                .filter(node -> node instanceof CheckBox)
                .map(node -> (CheckBox) node)
                .filter(CheckBox::isSelected)
                .map(CheckBox::getText)
                .collect(Collectors.joining(", "));

        // Envia a string de cursos selecionados de volta para o EditarPerfilController
        if (perfilController != null) {
            perfilController.receberCursosSelecionados(cursosSelecionados);
        }

        // Fecha o pop-up
        fechar(event);
    }

    @FXML
    private void handleCancelar(ActionEvent event) {
        // Apenas fecha o pop-up sem enviar dados
        fechar(event);
    }

    private void fechar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
