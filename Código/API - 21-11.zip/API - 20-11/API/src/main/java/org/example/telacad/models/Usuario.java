package org.example.telacad.models;

public class Usuario {
    private String email;
    private String nome;
    private String curso;
    private String senha;
    private int perfil;   // 1=aluno, 2=prof, 3=tg
    private int status;   // 0=inativo, 1=ativo

    public Usuario(String email, String nome, String curso, String senha, int perfil, int status) {
        this.email = email;
        this.nome = nome;
        this.curso = curso;
        this.senha = senha;
        this.perfil = perfil;
        this.status = status;
    }

    public String getEmail() { return email; }
    public String getNome() { return nome; }
    public String getCurso() { return curso; }
    public String getSenha() { return senha; }
    public int getPerfil() { return perfil; }
    public int getStatus() { return status; }

    public void setSenha(String senha) { this.senha = senha; }
    public void setStatus(int status) { this.status = status; }
    public void setEmail(String email) { this.email = email; }
    public void setNome(String nome) { this.nome = nome; }
}
