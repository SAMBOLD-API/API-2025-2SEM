package org.example.telacad;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class ManuaisController {

    private PerfilAlunoController perfilController;

    public void setPerfilController(PerfilAlunoController controller) {
        this.perfilController = controller;
    }

    @FXML
    private void handleFechar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
