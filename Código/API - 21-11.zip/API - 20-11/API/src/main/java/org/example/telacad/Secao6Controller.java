package org.example.telacad;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.List;

import org.example.telacad.db.FeedbackDAO;
import org.example.telacad.db.SecaoAPIDAO;
import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.models.Usuario;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Secao6Controller {

    // CAMPOS DO FORMULÁRIO
    @FXML private Label lblTitulo;
    @FXML private TextField txtEmpresa;
    @FXML private TextArea txtProblema;
    @FXML private TextArea txtSolucao;
    @FXML private ImageView imgDiagrama;
    @FXML private TextArea txtDetalhes1; // se não estiver no FXML, ignora
    @FXML private TextField txtGithubRepo;
    @FXML private TextArea txtTecnologias;
    @FXML private TextArea txtContribuicoes;
    @FXML private TextArea txtDetalhes2;
    @FXML private TextField txtHardSkills;
    @FXML private TextField txtSoftSkills;

    // BOTÕES E STATUS
    @FXML private Button btnEnviarVersao;
    @FXML private Button btnStatus;
    @FXML private Button btnUploadImagem;
    @FXML private StackPane statusContainer;
    @FXML private VBox containerFeedbacks;

    // VARIÁVEIS
    private String emailAluno;
    private String emailProf;
    private String imagemPath = "";
    private int numeroSecao = 1; // Padrão é Seção 1, mas DEVE ser definido antes de usar

    private final SecaoAPIDAO secaoAPIDAO = new SecaoAPIDAO();
    private final FeedbackDAO feedbackDAO = new FeedbackDAO();
    private final SolicitacaoDAO solicitacaoDAO = new SolicitacaoDAO();

    private enum Status {
        PENDENTE, EM_ANALISE, APROVADA, REPROVADA
    }

    /**
     * Define qual seção está sendo editada (1 a 6)
     * DEVE ser chamado antes de inicializar a tela por completo.
     */
    public void setNumeroSecao(int numero) {
        if (numero >= 1 && numero <= 6) {
            this.numeroSecao = numero;
            if (lblTitulo != null) {
                lblTitulo.setText("SEÇÃO " + numeroSecao);
            }
        } else {
            throw new IllegalArgumentException("Número de seção deve ser entre 1 e 6");
        }
    }

    /**
     * Retorna o número da seção atual
     */
    public int getNumeroSecao() {
        return numeroSecao;
    }

    @FXML
    public void initialize() {
        // Atualiza o título com o número da seção atual (pode ser ajustado depois via setNumeroSecao)
        if (lblTitulo != null) {
            lblTitulo.setText("SEÇÃO " + numeroSecao);
        }

        // Configurar botão de upload de imagem
        if (btnUploadImagem != null) {
            btnUploadImagem.setOnAction(e -> uploadImagem());
        }

        // NÃO carrega dados aqui! Será carregado no inicializarSecao() após setNumeroSecao()
    }

    /**
     * Método público para inicializar a seção DEPOIS de setNumeroSecao() ser chamado.
     * DEVE ser chamado pelo controller que abre esta tela.
     */
    public void inicializarSecao() {
        // Atualiza o título com o número correto da seção
        if (lblTitulo != null) {
            lblTitulo.setText("SEÇÃO " + numeroSecao);
        }

        // Carrega dados da sessão
        Usuario usuario = Sessao.getUsuario();
        if (usuario != null) {
            emailAluno = usuario.getEmail();

            // Buscar professor orientador
            try {
                emailProf = solicitacaoDAO.buscarProfessorOrientador(emailAluno);
                if (emailProf == null) {
                    mostrarAlerta("Aviso", "Você ainda não tem um professor orientador.");
                    return;
                }

                // Carregar dados salvos (AGORA com o numeroSecao correto!)
                carregarDados();

                // Atualizar status
                atualizarStatus();

                // Carregar feedbacks da seção atual para o aluno
                carregarFeedbacksAluno(numeroSecao);

            } catch (SQLException e) {
                e.printStackTrace();
                mostrarAlerta("Erro", "Erro ao carregar dados: " + e.getMessage());
            }
        }
    }

    /**
     * Carrega os dados salvos da Seção do banco de dados
     */
    private void carregarDados() throws SQLException {
        SecaoAPIDAO.SecaoAPIData dados = secaoAPIDAO.carregarSecaoAPI(emailAluno, numeroSecao);
        if (dados != null) {
            setText(txtEmpresa, dados.empresaParceira);
            setText(txtProblema, dados.problema);
            setText(txtSolucao, dados.solucao);
            setText(txtGithubRepo, dados.repositorio);
            setText(txtTecnologias, dados.tecnologias);
            setText(txtContribuicoes, dados.contribuicoes);
            setText(txtDetalhes2, dados.detalhesContribuicoes);
            setText(txtHardSkills, dados.hardSkills);
            setText(txtSoftSkills, dados.softSkills);

            // Carregar imagem se existir
            if (dados.solucaoImagemPath != null && !dados.solucaoImagemPath.isEmpty()) {
                imagemPath = dados.solucaoImagemPath;
                carregarImagem(dados.solucaoImagemPath);
            }
        }
    }

    /**
     * Atualiza o status da seção baseado no feedback
     */
    private void atualizarStatus() {
        try {
            Integer statusAprovacao = feedbackDAO.getStatusAprovacao(emailAluno, emailProf, numeroSecao);

            Status status;
            if (statusAprovacao == null) {
                // Verifica se já enviou
                if (secaoAPIDAO.secaoEnviada(emailAluno, emailProf, numeroSecao)) {
                    status = Status.EM_ANALISE;
                } else {
                    status = Status.PENDENTE;
                }
            } else if (statusAprovacao == 1) {
                status = Status.APROVADA;
            } else {
                status = Status.REPROVADA;
            }

            simularEstadoAtual(status);

        } catch (SQLException e) {
            e.printStackTrace();
            simularEstadoAtual(Status.PENDENTE);
        }
    }

    /**
     * Atualiza a interface com o status atual
     */
    private void simularEstadoAtual(Status status) {
        if (statusContainer == null) return;

        statusContainer.getChildren().clear();
        String texto = "";
        String estilo = "";
        boolean enviarDesabilitado = false;

        switch (status) {
            case PENDENTE:
                texto = "PENDENTE";
                estilo = "botao-status-pendente";
                enviarDesabilitado = false;
                break;
            case EM_ANALISE:
                texto = "EM ANÁLISE";
                estilo = "botao-status-em-analise";
                enviarDesabilitado = true;
                break;
            case APROVADA:
                texto = "APROVADA";
                estilo = "botao-status-aprovada";
                enviarDesabilitado = true;
                break;
            case REPROVADA:
                texto = "REPROVADA";
                estilo = "botao-status-reprovada";
                enviarDesabilitado = false;
                mostrarPopupReprovacao();
                break;
        }

        btnStatus = new Button(texto);
        btnStatus.getStyleClass().add(estilo);
        btnStatus.setDisable(true);
        statusContainer.getChildren().add(btnStatus);

        if (btnEnviarVersao != null) {
            btnEnviarVersao.setDisable(enviarDesabilitado);
        }
    }

    /**
     * Handler do botão "ENVIAR VERSÃO"
     * Salva os dados e marca como "Em Análise"
     */
    @FXML
    public void handleEnviarVersao() {
        try {
            // Validar campos obrigatórios
            if (!validarCampos()) {
                return;
            }

            // Salvar no banco
            salvarDados();

            // Criar feedback inicial (status = NULL = em análise)
            feedbackDAO.criarFeedbackInicial(emailAluno, emailProf, numeroSecao);

            // Mostrar popup de sucesso
            mostrarSucesso("Seção " + numeroSecao + " enviada para análise com sucesso!");

            // Atualizar status
            atualizarStatus();

            // Recarregar feedbacks (caso já existam registros anteriores)
            carregarFeedbacksAluno(numeroSecao);

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Erro ao enviar seção: " + e.getMessage());
        }
    }

    /**
     * Salva os dados da Seção no banco
     */
    private void salvarDados() throws SQLException {
        String empresa = getText(txtEmpresa);
        String problema = getText(txtProblema);
        String solucao = getText(txtSolucao);
        String repositorio = getText(txtGithubRepo);
        String tecnologias = getText(txtTecnologias);
        String contribuicoes = getText(txtContribuicoes);
        String detalhes = getText(txtDetalhes2);
        String hardSkills = getText(txtHardSkills);
        String softSkills = getText(txtSoftSkills);

        secaoAPIDAO.salvarSecaoAPI(
                emailAluno, emailProf, numeroSecao, empresa, problema, solucao,
                imagemPath, repositorio, tecnologias, contribuicoes,
                detalhes, hardSkills, softSkills
        );
    }

    /**
     * Valida se os campos obrigatórios estão preenchidos
     */
    private boolean validarCampos() {
        if (getText(txtEmpresa).isEmpty()) {
            mostrarAlerta("Campos Obrigatórios", "Por favor, preencha a empresa parceira.");
            return false;
        }
        if (getText(txtProblema).isEmpty()) {
            mostrarAlerta("Campos Obrigatórios", "Por favor, descreva o problema.");
            return false;
        }
        if (getText(txtSolucao).isEmpty()) {
            mostrarAlerta("Campos Obrigatórios", "Por favor, descreva a solução.");
            return false;
        }
        if (getText(txtGithubRepo).isEmpty()) {
            mostrarAlerta("Campos Obrigatórios", "Por favor, informe o repositório GitHub.");
            return false;
        }
        return true;
    }

    /**
     * Upload de imagem/diagrama (aluno pode reenviar se for reprovado)
     */
    private void uploadImagem() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecionar Imagem");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imagens", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );

        File selectedFile = fileChooser.showOpenDialog(btnUploadImagem.getScene().getWindow());
        if (selectedFile != null) {
            try {
                Path uploadsDir = Paths.get("uploads/solucoes");
                Files.createDirectories(uploadsDir);
                String fileName = System.currentTimeMillis() + "_" + selectedFile.getName();
                Path destino = uploadsDir.resolve(fileName);
                Files.copy(selectedFile.toPath(), destino, StandardCopyOption.REPLACE_EXISTING);
                imagemPath = destino.toString();
                carregarImagem(imagemPath);
            } catch (IOException e) {
                e.printStackTrace();
                mostrarAlerta("Erro", "Falha ao fazer upload da imagem: " + e.getMessage());
            }
        }
    }

    /**
     * Carrega imagem no ImageView
     */
    private void carregarImagem(String caminho) {
        if (imgDiagrama != null && caminho != null && !caminho.isEmpty()) {
            try {
                File file = new File(caminho);
                if (file.exists()) {
                    Image image = new Image(file.toURI().toString());
                    imgDiagrama.setImage(image);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Carrega os feedbacks do professor para a seção atual (1 a 6)
     * e mostra dentro do containerFeedbacks (lado do aluno).
     */
    private void carregarFeedbacksAluno(int numeroSecao) {
        if (containerFeedbacks == null) return;

        try {
            List<FeedbackDAO.FeedbackData> feedbacks =
                    feedbackDAO.carregarFeedbacks(emailAluno, numeroSecao);

            containerFeedbacks.getChildren().clear();

            for (FeedbackDAO.FeedbackData fb : feedbacks) {
                if (fb.comentario == null || fb.comentario.trim().isEmpty()) {
                    continue;
                }

                Label lbl = new Label(fb.comentario);
                lbl.getStyleClass().add("feedback-item");
                lbl.setWrapText(true);
                lbl.setMaxWidth(Double.MAX_VALUE);

                // espaçamento entre feedbacks
                VBox.setMargin(lbl, new Insets(0, 0, 8, 0));

                containerFeedbacks.getChildren().add(lbl);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Erro ao carregar feedbacks da seção " + numeroSecao + ": " + e.getMessage());
        }
    }

    private void abrirPopup(String fxmlPath) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Parent root = loader.load();

        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.initStyle(StageStyle.TRANSPARENT);

        Scene scene = new Scene(root);
        scene.setFill(null);
        popupStage.setScene(scene);

        Stage stagePrincipal = (Stage) btnEnviarVersao.getScene().getWindow();
        popupStage.setX(stagePrincipal.getX());
        popupStage.setY(stagePrincipal.getY());
        popupStage.setWidth(stagePrincipal.getWidth());
        popupStage.setHeight(stagePrincipal.getHeight());

        // LIGAÇÃO AOS NOVOS CONTROLLERS
        if (loader.getController() instanceof PopupConfirmarController6) {
            PopupConfirmarController6 controller = (PopupConfirmarController6) loader.getController();
            controller.setSecaoController(this);
        } else if (loader.getController() instanceof PopupSucessoController6) {
            PopupSucessoController6 controller = (PopupSucessoController6) loader.getController();
            controller.setSecaoController(this);
        }

        popupStage.showAndWait();
    }

    private void mostrarPopupReprovacao() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Seção Reprovada");
        alert.setHeaderText("Sua Seção " + numeroSecao + " foi reprovada pelo professor");
        alert.setContentText("Você pode alterar e enviar novamente clicando em 'ENVIAR VERSÃO'.");
        alert.showAndWait();
    }

    @FXML
    private void handleVoltarParaPerfil(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/org/example/telacad/home-aluno.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 1000, 700);
        stage.setScene(scene);
        stage.show();
    }

    // ===== MÉTODOS AUXILIARES =====

    private String getText(TextField field) {
        return field != null && field.getText() != null ? field.getText().trim() : "";
    }

    private String getText(TextArea field) {
        return field != null && field.getText() != null ? field.getText().trim() : "";
    }

    private void setText(TextField field, String text) {
        if (field != null) {
            field.setText(text != null ? text : "");
        }
    }

    private void setText(TextArea field, String text) {
        if (field != null) {
            field.setText(text != null ? text : "");
        }
    }

    private void mostrarAlerta(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    private void mostrarSucesso(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Sucesso");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    public void confirmarEnvio() throws IOException {
        simularEstadoAtual(Status.EM_ANALISE);
        abrirPopup("/org/example/telacad/PopupEnvioSucesso6.fxml");
    }

    public void fecharPopup(ActionEvent event) {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
