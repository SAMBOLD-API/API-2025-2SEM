package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Diz quantas seções um aluno já enviou para um professor.
 *
 * Usa:
 *  - secao_0        -> seção 0 (vale 1 se existir o registro)
 *  - secao_api      -> seções 1..6 (conta DISTINCT numero_secao)
 */
public class SecaoStatusDAO {

    // 1 (secao_0) + 6 (secao_api: 1..6)
    public static final int TOTAL_SECOES = 7;

    /**
     * Retorna o total de seções enviadas por um aluno para um professor.
     *
     * @param emailAluno email do aluno
     * @param emailProf  email do professor
     * @return quantidade de seções diferentes enviadas (0..7)
     */
    public int contarSecoesEnviadas(String emailAluno, String emailProf) throws SQLException {
        int total = 0;

        // 1) Verifica se a seção 0 foi enviada (secao_0)
        String sqlSecao0 =
                "SELECT 1 " +
                "FROM secao_0 " +
                "WHERE email_aluno = ? AND email_prof = ? " +
                "LIMIT 1";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps0 = conn.prepareStatement(sqlSecao0)) {

            ps0.setString(1, emailAluno);
            ps0.setString(2, emailProf);

            try (ResultSet rs = ps0.executeQuery()) {
                if (rs.next()) {
                    // Se existe uma linha, conta como 1 seção (seção 0)
                    total += 1;
                }
            }

            // 2) Conta quantas seções 1..6 existem na secao_api
            String sqlSecaoApi =
                    "SELECT COUNT(DISTINCT numero_secao) AS qtd " +
                    "FROM secao_api " +
                    "WHERE email_aluno = ? AND email_prof = ?";

            try (PreparedStatement psApi = conn.prepareStatement(sqlSecaoApi)) {
                psApi.setString(1, emailAluno);
                psApi.setString(2, emailProf);

                try (ResultSet rsApi = psApi.executeQuery()) {
                    if (rsApi.next()) {
                        total += rsApi.getInt("qtd");
                    }
                }
            }
        }

        // total vai ficar entre 0 e 7
        return total;
    }
}
