package org.example.telacad.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.example.telacad.models.ChatMensagem;

public class ChatMessageDAO {

    public void salvarMensagem(String emailAluno, String emailProf, String sender, String texto) throws SQLException {
        // Verificação redundante no DAO para garantir integridade caso seja chamado de outro lugar.
        if (!existeVinculoAceito(emailAluno, emailProf)) {
            throw new SQLException("Vínculo não aceito entre aluno e professor. Mensagem não será salva.");
        }

        String sql = "INSERT INTO chat_mensagem (email_aluno, email_prof, sender, texto, created_at) VALUES (?,?,?,?,?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setString(3, sender);
            ps.setString(4, texto);
            ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            ps.executeUpdate();
        }
    }

    public List<ChatMensagem> listarMensagens(String emailAluno, String emailProf, int limit) throws SQLException {
    // ✅ Mudei para ASC (crescente) - mensagens mais antigas primeiro
    String sql = "SELECT id, email_aluno, email_prof, sender, texto, created_at " +
                 "FROM chat_mensagem " +
                 "WHERE email_aluno = ? AND email_prof = ? " +
                 "ORDER BY created_at ASC " +
                 "LIMIT ?";
    
    List<ChatMensagem> out = new ArrayList<>();
    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, emailAluno);
        ps.setString(2, emailProf);
        ps.setInt(3, limit);
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ChatMensagem m = new ChatMensagem(
                        rs.getLong("id"),
                        rs.getString("email_aluno"),
                        rs.getString("email_prof"),
                        rs.getString("sender"),
                        rs.getString("texto"),
                        rs.getTimestamp("created_at").toLocalDateTime()
                );
                out.add(m);
            }
        }
    }
    return out;
}

    public boolean existeVinculoAceito(String emailAluno, String emailProf) throws SQLException {
        // Ajuste o nome/colunas conforme seu schema real de 'solicitacao'
        // status = 2 significa "aceito"
        String sql = "SELECT 1 FROM solicitacao WHERE email_aluno = ? AND email_prof = ? AND _status = 2";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}
