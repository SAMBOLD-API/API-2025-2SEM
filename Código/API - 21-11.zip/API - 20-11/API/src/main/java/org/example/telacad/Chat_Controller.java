package org.example.telacad;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.example.telacad.db.DocumentoDAO;
import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.models.Documento;
import org.example.telacad.models.Usuario;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Chat_Controller {

    @FXML private VBox chatVBox;
    @FXML private ScrollPane chatScrollPane;
    @FXML private Button voltarBtn;
    @FXML private Button perfilBtn;

    @FXML private VBox overlayPane;
    @FXML private VBox documentPopupVBox;
    @FXML private Label docEmptyMessageLabel;
    @FXML private ScrollPane docScrollPane;
    @FXML private VBox docListVBox;

    private String emailProfSelecionado;
    private String nomeProfSelecionado;

    @FXML private TextField inputField;

    private static final String DOC_ICON_SVG = "M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z";

    @FXML
    public void initialize() {
        carregarProfessorVinculado();
        carregarHistoricoMensagens();
    }

    private void carregarHistoricoMensagens() {
        try {
            Usuario aluno = Sessao.getUsuario();
            if (aluno == null || emailProfSelecionado == null) {
                System.err.println("Aluno ou professor não carregado ainda.");
                return;
            }

            Usuario prof = new Usuario(emailProfSelecionado, nomeProfSelecionado, "", "", 2, 1);
            
            ChatService chat = new ChatService();
            List<org.example.telacad.models.ChatMensagem> mensagens = chat.load(aluno, prof, 100);

            if (mensagens.isEmpty()) {
                System.out.println("Nenhuma mensagem encontrada no histórico.");
                return;
            }

            if (chatVBox != null) {
                chatVBox.getChildren().clear();
            }

            for (org.example.telacad.models.ChatMensagem msg : mensagens) {
                boolean isAluno = "aluno".equalsIgnoreCase(msg.getSender());
                adicionarMensagem(msg.getTexto(), isAluno);
            }

            Platform.runLater(() -> {
                if (chatScrollPane != null) chatScrollPane.setVvalue(1.0);
            });

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Erro ao carregar histórico: " + e.getMessage());
        }
    }

    @FXML
    private void enviarMensagemAluno(ActionEvent e) {
        String texto = inputField.getText();
        if (texto == null || texto.trim().isEmpty()) return;

        Usuario aluno = Sessao.getUsuario();
        if (aluno == null) return;

        if (emailProfSelecionado == null) {
            carregarProfessorVinculado();
            if (emailProfSelecionado == null) {
                System.err.println("Sem professor vinculado.");
                return;
            }
        }

        try {
            Usuario prof = new Usuario(emailProfSelecionado, nomeProfSelecionado, "", "", 2, 1);
            ChatService chat = new ChatService();
            chat.appendFromAluno(aluno, prof, texto);

            adicionarMensagem(texto, true);
            inputField.clear();
        } catch (Exception ex) {
            ex.printStackTrace();
            Platform.runLater(() -> {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Falha ao enviar mensagem");
                alert.setHeaderText(null);
                alert.setContentText(ex.getMessage() != null ? ex.getMessage() : "Erro desconhecido.");
                alert.initOwner(inputField.getScene().getWindow());
                alert.showAndWait();
            });
        }
    }

    @FXML
    private void sendMessage(ActionEvent event) {
        enviarMensagemAluno(event);
    }

    private void adicionarMensagem(String message, boolean isSent) {
        if (chatVBox == null) return;
        Label messageLabel = new Label(message);
        messageLabel.setWrapText(true);
        HBox messageContainer = new HBox();
        if (isSent) {
            messageLabel.getStyleClass().add("message-bubble-sent");
            messageContainer.setAlignment(Pos.CENTER_RIGHT);
        } else {
            messageLabel.getStyleClass().add("message-bubble-received");
            messageContainer.setAlignment(Pos.CENTER_LEFT);
        }
        messageContainer.getChildren().add(messageLabel);
        chatVBox.getChildren().add(messageContainer);
        Platform.runLater(() -> {
            if(chatScrollPane != null) chatScrollPane.setVvalue(1.0);
        });
    }

    @FXML
    private void voltar() {
        try {
            Stage stagePrincipal = (Stage) voltarBtn.getScene().getWindow();
            Parent loginPage = FXMLLoader.load(getClass().getResource("/org/example/telacad/home-aluno.fxml"));
            Scene loginScene = new Scene(loginPage);
            stagePrincipal.setScene(loginScene);
            stagePrincipal.setTitle("Home Aluno");
            stagePrincipal.setMaximized(true);
            stagePrincipal.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirPerfil() {
        try {
            Stage stagePrincipal = (Stage) perfilBtn.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/telacad/perfil_aluno.fxml"));
            Parent root = loader.load();
            Stage popupStage = new Stage();
            popupStage.initOwner(stagePrincipal);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.initStyle(StageStyle.TRANSPARENT);
            popupStage.setMaximized(true);
            Scene scene = new Scene(root);
            scene.setFill(Color.TRANSPARENT);
            popupStage.setScene(scene);
            popupStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ✅ Aluno visualiza e baixa documentos enviados pelo professor
    @FXML
    private void handleOpenDocuments(ActionEvent event) {
        Usuario aluno = Sessao.getUsuario();
        if (aluno == null || emailProfSelecionado == null) {
            mostrarAlerta("Erro", "Não foi possível carregar os documentos.");
            return;
        }

        try {
            DocumentoDAO dao = new DocumentoDAO();
            List<Documento> documentos = dao.listarDocumentos(aluno.getEmail(), emailProfSelecionado);
            populateAndShowDocumentPopup(documentos);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Falha ao carregar documentos: " + e.getMessage());
        }
    }

    @FXML
    private void closeDocumentPopup() {
        if (documentPopupVBox != null) documentPopupVBox.setVisible(false);
        if (overlayPane != null) overlayPane.setVisible(false);
    }

    private void populateAndShowDocumentPopup(List<Documento> documents) {
        if (docListVBox == null || docEmptyMessageLabel == null || docScrollPane == null || 
            overlayPane == null || documentPopupVBox == null) {
            System.err.println("Erro: Componentes do pop-up não injetados.");
            return;
        }
        
        docListVBox.getChildren().clear();
        
        if (documents == null || documents.isEmpty()) {
            docEmptyMessageLabel.setVisible(true);
            docScrollPane.setVisible(false);
        } else {
            docEmptyMessageLabel.setVisible(false);
            docScrollPane.setVisible(true);
            for (Documento doc : documents) {
                docListVBox.getChildren().add(createDocumentItemWithDownload(doc));
            }
        }
        
        overlayPane.setVisible(true);
        documentPopupVBox.setVisible(true);
    }

    private HBox createDocumentItemWithDownload(Documento documento) {
        SVGPath docIcon = new SVGPath();
        docIcon.setContent(DOC_ICON_SVG);
        docIcon.getStyleClass().add("document-icon-style");

        VBox infoBox = new VBox(2);
        Label nameLabel = new Label(documento.getNomeArquivo());
        nameLabel.getStyleClass().add("document-name-style");
        Label sizeLabel = new Label(documento.getTamanhoFormatado());
        sizeLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #666;");
        infoBox.getChildren().addAll(nameLabel, sizeLabel);

        Button downloadBtn = new Button("⬇ Baixar");
        downloadBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 5 10;");
        downloadBtn.setOnAction(e -> baixarDocumento(documento));

        HBox item = new HBox(10, docIcon, infoBox, downloadBtn);
        item.getStyleClass().add("document-item-style");
        item.setAlignment(Pos.CENTER_LEFT);
        item.setStyle("-fx-padding: 10; -fx-background-color: #f5f5f5; -fx-background-radius: 5;");

        return item;
    }

    private void baixarDocumento(Documento documento) {
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Salvar Arquivo");
            fileChooser.setInitialFileName(documento.getNomeArquivo());
            
            File destino = fileChooser.showSaveDialog(voltarBtn.getScene().getWindow());
            
            if (destino != null) {
                Path origem = Paths.get(documento.getCaminhoArquivo());
                Files.copy(origem, destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
                
                mostrarAlerta("Sucesso", "Arquivo baixado com sucesso!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Falha ao baixar arquivo: " + e.getMessage());
        }
    }

    private void carregarProfessorVinculado() {
        try {
            Usuario aluno = Sessao.getUsuario();
            if (aluno == null) return;

            SolicitacaoDAO dao = new SolicitacaoDAO();
            Usuario prof = dao.obterProfessorAceitoPorAluno(aluno.getEmail());
            if (prof != null) {
                this.emailProfSelecionado = prof.getEmail();
                this.nomeProfSelecionado  = prof.getNome();
            } else {
                System.err.println("Nenhum professor aceito para o aluno " + aluno.getEmail());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void mostrarAlerta(String titulo, String mensagem) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(titulo);
            alert.setHeaderText(null);
            alert.setContentText(mensagem);
            alert.initOwner(voltarBtn.getScene().getWindow());
            alert.showAndWait();
        });
    }
}
