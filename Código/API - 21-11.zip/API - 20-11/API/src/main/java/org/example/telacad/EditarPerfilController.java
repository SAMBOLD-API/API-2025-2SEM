package org.example.telacad;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class EditarPerfilController {

    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtSenha;
    @FXML
    private TextField txtConfirmaSenha;
    @FXML
    private Button btnCursos;
    @FXML
    private Button btnFechar;

    @FXML
    private void handleFechar() {
        Stage stage = (Stage) btnFechar.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleAtualizar() throws IOException {
        if (txtSenha.getText().isEmpty() || !txtSenha.getText().equals(txtConfirmaSenha.getText())) {
            System.out.println("Erro: Senhas não coincidem ou estão vazias.");
            return;
        }

        abrirPopup("/ConfirmarPerfilView.fxml", true);
    }

    @FXML
    private void handleSelecionarCursos() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/SelecionarCursosView.fxml"));
        Parent root = loader.load();

        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);

        // MUDANÇA: Voltando para TRANSPARENTE
        popupStage.initStyle(StageStyle.TRANSPARENT);

        Scene scene = new Scene(root);
        scene.setFill(null); // Permite a transparência
        popupStage.setScene(scene);

        Stage mainStage = (Stage) btnCursos.getScene().getWindow();

        // Faz o pop-up escuro cobrir a tela inteira
        popupStage.setX(mainStage.getX());
        popupStage.setY(mainStage.getY());
        popupStage.setWidth(mainStage.getWidth());
        popupStage.setHeight(mainStage.getHeight());

        if (loader.getController() instanceof SelecionarCursosController) {
            SelecionarCursosController controller = loader.getController();
            controller.setPerfilController(this);
        }

        popupStage.showAndWait();
    }

    public void receberCursosSelecionados(String cursos) {
        btnCursos.setText(cursos.isEmpty() ? "Selecionar Cursos" : cursos);
    }

    private void abrirPopup(String fxmlPath, boolean transparente) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Parent root = loader.load();

        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);

        if (transparente) {
            popupStage.initStyle(StageStyle.TRANSPARENT);
        } else {
            popupStage.initStyle(StageStyle.UNDECORATED);
        }

        Scene scene = new Scene(root);
        if (transparente) {
            scene.setFill(null);
        }
        popupStage.setScene(scene);

        Stage mainStage = (Stage) btnFechar.getScene().getWindow();
        popupStage.setX(mainStage.getX());
        popupStage.setY(mainStage.getY());
        popupStage.setWidth(mainStage.getWidth());
        popupStage.setHeight(mainStage.getHeight());

        if (loader.getController() instanceof ConfirmarPerfilController) {
            ConfirmarPerfilController controller = loader.getController();
            controller.setPerfilController(this);
        } else if (loader.getController() instanceof SucessoPerfilController) {
            SucessoPerfilController controller = loader.getController();
            controller.setPerfilController(this);
        }

        popupStage.showAndWait();
    }

    public void confirmarAtualizacao() throws IOException {
        System.out.println("Perfil atualizado: " + txtNome.getText());
        abrirPopup("/SucessoPerfilView.fxml", true);
    }

    public void fecharPopup(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
}
