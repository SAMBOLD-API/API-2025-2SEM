package org.example.telacad;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import org.example.telacad.db.OrientacaoDAO;
import org.example.telacad.db.OrientacaoDAO.AlunoOrientado;
import org.example.telacad.models.Usuario;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class OrientacaoController implements Initializable {

    @FXML
    private AnchorPane rootPane;   // painel verde

    @FXML
    private AnchorPane modalPane;  // painel branco

    @FXML
    private Label closeButton;

    // Caixas de estatísticas
    @FXML
    private Label lblTotalOrientacoes;

    @FXML
    private Label lblPendentes;

    @FXML
    private Label lblEmAndamento;

    @FXML
    private Label lblConcluidos;

    // Barras do gráfico (usamos só 0,1,2 = Nenhuma, Parcial, Todas)
    @FXML private Pane bar0; // Nenhuma
    @FXML private Pane bar1; // Parcial
    @FXML private Pane bar2; // Todas

    @FXML private Pane bar3;
    @FXML private Pane bar4;
    @FXML private Pane bar5;
    @FXML private Pane bar6;

    // Lista de alunos
    @FXML
    private VBox alunosVBox;

    @FXML
    private Label alunosTitleLabel;

    private double xOffset = 0;
    private double yOffset = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // Voltar para home do professor
        closeButton.setOnMouseClicked(event -> {
            try {
                FXMLLoader loader = new FXMLLoader(
                        getClass().getResource("/org/example/telacad/home-professor.fxml"));
                Parent homeRoot = loader.load();

                Stage stage = (Stage) closeButton.getScene().getWindow();
                Scene scene = new Scene(homeRoot);

                stage.setScene(scene);
                stage.setTitle("Home Professor");
                stage.setMaximized(true);
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        // Arrastar janela
        modalPane.setOnMousePressed(event -> {
            xOffset = event.getSceneX();
            yOffset = event.getSceneY();
        });

        modalPane.setOnMouseDragged(event -> {
            Stage stage = (Stage) modalPane.getScene().getWindow();
            stage.setX(event.getScreenX() - xOffset);
            stage.setY(event.getScreenY() - yOffset);
        });

        // Carregar dados
        carregarDados();
    }

    private void carregarDados() {
        Usuario usuarioLogado = Sessao.getUsuario();
        if (usuarioLogado == null) {
            System.err.println("Nenhum usuário na sessão.");
            return;
        }

        String emailProf = usuarioLogado.getEmail();

        OrientacaoDAO dao = new OrientacaoDAO();

        try {
            List<AlunoOrientado> alunos = dao.listarAlunosOrientados(emailProf);

            int total = alunos.size();
            int pendentes = 0;
            int emAndamento = 0;
            int concluidos = 0;

            int nenhuma = 0;
            int parcial = 0;
            int todas = 0;

            for (AlunoOrientado a : alunos) {
                boolean hasSecao0 = a.isHasSecao0();
                int qtdApi = a.getQtdSecaoApi();
                int totalSecoes = a.getQtdTotalSecoes(); // 0..7

                // REGRAS:
                //  - PENDENTE / NENHUMA:
                //        não tem secao_0 e não tem nenhuma secao_api
                //  - EM ANDAMENTO / PARCIAL:
                //        tem pelo menos uma seção (0 ou 1..6), mas não tem todas as 7
                //  - CONCLUÍDO / TODAS:
                //        tem secao_0 + TODAS as 6 seções (totalSecoes == 7)
                if (!hasSecao0 && qtdApi == 0) {
                    pendentes++;
                    nenhuma++;
                } else if (totalSecoes < 7) {
                    emAndamento++;
                    parcial++;
                } else {
                    concluidos++;
                    todas++;
                }
            }

            // Atualiza caixas
            lblTotalOrientacoes.setText(String.valueOf(total));
            lblPendentes.setText(String.valueOf(pendentes));
            lblEmAndamento.setText(String.valueOf(emAndamento));
            lblConcluidos.setText(String.valueOf(concluidos));

            // Atualiza gráfico
            atualizarGrafico(nenhuma, parcial, todas);

            // Atualiza lista
            atualizarListaAlunos(alunos);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void atualizarGrafico(int nenhuma, int parcial, int todas) {
        int max = Math.max(nenhuma, Math.max(parcial, todas));
        if (max == 0) {
            max = 1;
        }

        double alturaMax = 140.0;

        double hNenhuma = (nenhuma / (double) max) * alturaMax;
        double hParcial = (parcial / (double) max) * alturaMax;
        double hTodas   = (todas   / (double) max) * alturaMax;

        if (nenhuma > 0 && hNenhuma < 20) hNenhuma = 20;
        if (parcial > 0 && hParcial < 20) hParcial = 20;
        if (todas   > 0 && hTodas   < 20) hTodas   = 20;

        bar0.setPrefHeight(hNenhuma);
        bar1.setPrefHeight(hParcial);
        bar2.setPrefHeight(hTodas);

        // Garante que as outras fiquem zeradas
        bar3.setPrefHeight(0);
        bar4.setPrefHeight(0);
        bar5.setPrefHeight(0);
        bar6.setPrefHeight(0);
    }

    private void atualizarListaAlunos(List<AlunoOrientado> alunos) {
        alunosVBox.getChildren().clear();
        alunosVBox.getChildren().add(alunosTitleLabel);

        for (AlunoOrientado a : alunos) {
            String texto = a.getNome() + " (" + a.getEmail() + ")";
            Label lbl = new Label(texto);
            lbl.getStyleClass().add("aluno-name");
            alunosVBox.getChildren().add(lbl);
        }
    }
}
