package org.example.telacad;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.example.telacad.db.UsuarioDAO;
import org.example.telacad.models.Usuario;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Perfil_ProfessorController {

    @FXML private Button closeButton;
    @FXML private Button atualizarBtn;
    @FXML private VBox dialogPane;
    @FXML private TextField nomeField;
    @FXML private TextField emailField;
    @FXML private PasswordField senhaField;
    @FXML private PasswordField confirmarSenhaField;
    @FXML private TextField cursoTextField;

    @FXML private Button okButton;
    @FXML private VBox sucessoDialog;
    @FXML private VBox cursosDialog;
    @FXML private VBox cursosContainer;

    private double xOffset = 0;
    private double yOffset = 0;

    private final List<String> TODOS_OS_CURSOS = Arrays.asList(
            "Análise e Desenvolvimento de Sistemas",
            "Banco de Dados",
            "Desenvolvimento de Software Multiplataforma",
            "Gestão da Produção Industrial",
            "Gestão Empresarial",
            "Logística",
            "Manufatura Avançada",
            "Manutenção de Aeronaves",
            "Projetos de Estruturas Aeronáuticas"
    );

    @FXML
    public void initialize() {
        setupDraggable(dialogPane);

        // Popula checkboxes de cursos
        if (cursosContainer != null) {
            for (String nomeCurso : TODOS_OS_CURSOS) {
                CheckBox checkBox = new CheckBox(nomeCurso);
                checkBox.getStyleClass().add("curso-checkbox");
                cursosContainer.getChildren().add(checkBox);
            }
        }

        carregarDadosUsuario();
    }

    private void carregarDadosUsuario() {
        Usuario usuario = Sessao.getUsuario();
        if (usuario != null) {
            if (nomeField != null) nomeField.setText(usuario.getNome());
            if (emailField != null) emailField.setText(usuario.getEmail());
            if (cursoTextField != null) cursoTextField.setText(usuario.getCurso());

            // Marca checkboxes dos cursos já cadastrados
            if (cursosContainer != null && usuario.getCurso() != null) {
                String[] cursosCadastrados = usuario.getCurso().split(",");
                for (var node : cursosContainer.getChildren()) {
                    if (node instanceof CheckBox cb) {
                        for (String curso : cursosCadastrados) {
                            if (cb.getText().trim().equals(curso.trim())) {
                                cb.setSelected(true);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    @FXML
    private void handleAbrirCursosDialog() {
        if (dialogPane != null) dialogPane.setDisable(true);
        if (cursosDialog != null) cursosDialog.setVisible(true);
    }

    @FXML
    private void handleConfirmarCursos() {
        if (cursosContainer != null) {
            String cursosSelecionados = cursosContainer.getChildren().stream()
                    .filter(node -> node instanceof CheckBox && ((CheckBox) node).isSelected())
                    .map(node -> ((CheckBox) node).getText())
                    .collect(Collectors.joining(", "));

            if (cursoTextField != null) cursoTextField.setText(cursosSelecionados);
        }

        if (cursosDialog != null) cursosDialog.setVisible(false);
        if (dialogPane != null) dialogPane.setDisable(false);
    }

    @FXML
    private void handleAtualizar() {
        try {
            Usuario usuarioAtual = Sessao.getUsuario();
            if (usuarioAtual == null) {
                mostrarAlerta("Erro", "Sessão inválida. Faça login novamente.");
                return;
            }

            // Valores digitados (podem estar vazios)
            String nomeDigitado    = nomeField        != null ? nomeField.getText().trim()           : "";
            String emailDigitado   = emailField       != null ? emailField.getText().trim()          : "";
            String cursosDigitado  = cursoTextField   != null ? cursoTextField.getText().trim()      : "";
            String senhaDigitada   = senhaField       != null ? senhaField.getText()                 : "";
            String confirmSenha    = confirmarSenhaField != null ? confirmarSenhaField.getText()     : "";

            // Se nada foi informado, não faz sentido atualizar
            boolean nenhumCampoPreenchido =
                    nomeDigitado.isEmpty() &&
                    emailDigitado.isEmpty() &&
                    cursosDigitado.isEmpty() &&
                    senhaDigitada.isEmpty() &&
                    confirmSenha.isEmpty();

            if (nenhumCampoPreenchido) {
                mostrarAlerta("Aviso", "Nenhuma alteração foi informada.");
                return;
            }

            // Regras de senha: só altera se os DOIS campos estiverem preenchidos
            String novaSenha = null;
            boolean querAlterarSenha = !senhaDigitada.isEmpty() || !confirmSenha.isEmpty();

            if (querAlterarSenha) {
                if (senhaDigitada.isEmpty() || confirmSenha.isEmpty()) {
                    mostrarAlerta("Erro", "Para alterar a senha, preencha os dois campos de senha.");
                    return;
                }
                if (!senhaDigitada.equals(confirmSenha)) {
                    mostrarAlerta("Erro", "As senhas não conferem.");
                    return;
                }
                novaSenha = senhaDigitada;
            }

            // Se o campo estiver vazio, mantém o valor atual
            String nomeFinal   = nomeDigitado.isEmpty()   ? usuarioAtual.getNome()   : nomeDigitado;
            String emailFinal  = emailDigitado.isEmpty()  ? usuarioAtual.getEmail()  : emailDigitado;
            String cursosFinal = cursosDigitado.isEmpty() ? usuarioAtual.getCurso()  : cursosDigitado;

            UsuarioDAO dao = new UsuarioDAO();
            // novaSenha == null → DAO não mexe na senha
            dao.atualizarUsuario(usuarioAtual.getEmail(), emailFinal, nomeFinal, cursosFinal, novaSenha);

            // Atualiza sessão com dados realmente salvos
            Usuario usuarioAtualizado = new Usuario(
                    emailFinal,
                    nomeFinal,
                    cursosFinal,
                    (novaSenha != null ? novaSenha : usuarioAtual.getSenha()),
                    usuarioAtual.getPerfil(),
                    usuarioAtual.getStatus()
            );
            Sessao.setUsuario(usuarioAtualizado);

            // Mostra sucesso
            if (dialogPane != null) dialogPane.setVisible(false);
            if (cursosDialog != null) cursosDialog.setVisible(false);
            if (sucessoDialog != null) sucessoDialog.setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Falha ao atualizar: " + e.getMessage());
        }
    }

    @FXML
    private void okButton() {
        handleClose();
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }

    private void setupDraggable(VBox pane) {
        if (pane == null) return;
        pane.setOnMousePressed(event -> {
            xOffset = event.getSceneX();
            yOffset = event.getSceneY();
        });

        pane.setOnMouseDragged(event -> {
            Stage stage = (Stage) pane.getScene().getWindow();
            stage.setX(event.getScreenX() - xOffset);
            stage.setY(event.getScreenY() - yOffset);
        });
    }

    private void mostrarAlerta(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
