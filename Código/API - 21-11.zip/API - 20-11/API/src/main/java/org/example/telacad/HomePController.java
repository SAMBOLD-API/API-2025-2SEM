package org.example.telacad;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.example.telacad.db.DocumentoDAO;
import org.example.telacad.db.SolicitacaoDAO;
import org.example.telacad.db.UsuarioDAO;
import org.example.telacad.models.Documento;
import org.example.telacad.models.Solicitacao;
import org.example.telacad.models.Usuario;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.SVGPath;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class HomePController {

    @FXML private VBox solicitacoesVBox;
    @FXML private TextField messageInputField;
    @FXML private Button addUserButton;
    @FXML private VBox messageVBox;
    @FXML private Button sairBtn;
    @FXML private Button minhaorientacao;
    @FXML private Button perfilBtn;
    @FXML private VBox listaAlunosVBox;
    @FXML private ScrollPane messageScrollPane;
    @FXML private VBox chatContainer;
    @FXML private Label chatAlunoNomeLabel;
    @FXML private Label emptyChatMessage;
    @FXML private VBox overlayPane;
    @FXML private VBox documentPopupVBox;
    @FXML private Label docEmptyMessageLabel;
    @FXML private ScrollPane docScrollPane;
    @FXML private VBox docListVBox;

    // diálogos de aprovação/recusa
    @FXML private VBox aprovacaoDialog;
    @FXML private VBox sucessoAprovacaoDialog;
    @FXML private VBox recusaDialog;
    @FXML private VBox sucessoDialog;
    @FXML private CheckBox justificativa1;
    @FXML private CheckBox justificativa2;
    @FXML private CheckBox justificativa3;

    private final List<Aluno> alunosAtivos = new ArrayList<>();
    private String emailAlunoChatAtual = null;
    private String emailAlunoAprovacaoPendente = null;
    private String emailAlunoRecusaPendente = null;

    private static class Aluno {
        final int id;
        final String nome;
        final String email;
        final String status;

        Aluno(int id, String nome, String email, String status) {
            this.id = id;
            this.nome = nome;
            this.email = email;
            this.status = status;
        }
    }

    @FXML
    public void initialize() {
        carregarSolicitacoes();
        carregarAlunosAceitos();

        if (messageInputField != null) {
            messageInputField.setOnAction(this::enviarMensagem);
        }

        configurarVisibilidadeBotaoAddProfessor();
        configurarCheckboxesJustificativa();
    }

    // =================== CONFIGURAÇÕES INICIAIS ===================

    private void configurarVisibilidadeBotaoAddProfessor() {
        Usuario usuarioLogado = Sessao.getUsuario();
        if (usuarioLogado != null && usuarioLogado.getPerfil() != 3 && addUserButton != null) {
            addUserButton.setVisible(false);
            addUserButton.setManaged(false);
        }
    }

    private void configurarCheckboxesJustificativa() {
        if (justificativa1 != null) {
            justificativa1.selectedProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal) desmarcarOutrosCheckboxes(justificativa1);
            });
        }
        if (justificativa2 != null) {
            justificativa2.selectedProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal) desmarcarOutrosCheckboxes(justificativa2);
            });
        }
        if (justificativa3 != null) {
            justificativa3.selectedProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal) desmarcarOutrosCheckboxes(justificativa3);
            });
        }
    }

    private void desmarcarOutrosCheckboxes(CheckBox selecionado) {
        if (justificativa1 != null && justificativa1 != selecionado) justificativa1.setSelected(false);
        if (justificativa2 != null && justificativa2 != selecionado) justificativa2.setSelected(false);
        if (justificativa3 != null && justificativa3 != selecionado) justificativa3.setSelected(false);
    }

    // =================== CHAT ===================

    @FXML
    private void enviarMensagem(ActionEvent e) {
        String texto = messageInputField != null ? messageInputField.getText() : "";
        if (texto == null || texto.trim().isEmpty()) return;

        Usuario prof = Sessao.getUsuario();
        if (prof == null || emailAlunoChatAtual == null) return;

        try {
            Usuario aluno = new Usuario(emailAlunoChatAtual, chatAlunoNomeLabel.getText(), "", "", 1, 1);
            ChatService chat = new ChatService();
            chat.appendFromProf(aluno, prof, texto);

            Platform.runLater(() -> {
                if (!messageScrollPane.isVisible()) {
                    emptyChatMessage.setVisible(false);
                    messageScrollPane.setVisible(true);
                }
                adicionarMensagem(texto, false);
                messageInputField.clear();
                if (messageScrollPane != null) messageScrollPane.setVvalue(1.0);
            });
        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarErro("Erro ao enviar mensagem", ex.getMessage());
        }
    }

    private void abrirChatPopup(String nomeAluno, String emailAluno) {
        emailAlunoChatAtual = emailAluno;
        chatAlunoNomeLabel.setText(nomeAluno);

        if (messageVBox != null) messageVBox.getChildren().clear();

        try {
            Usuario prof = Sessao.getUsuario();
            if (prof == null) return;

            Usuario aluno = new Usuario(emailAluno, nomeAluno, "", "", 1, 1);
            ChatService chat = new ChatService();
            List<org.example.telacad.models.ChatMensagem> mensagens = chat.load(aluno, prof, 100);

            if (mensagens.isEmpty()) {
                emptyChatMessage.setVisible(true);
                messageScrollPane.setVisible(false);
            } else {
                emptyChatMessage.setVisible(false);
                messageScrollPane.setVisible(true);

                for (org.example.telacad.models.ChatMensagem msg : mensagens) {
                    boolean isAluno = "aluno".equalsIgnoreCase(msg.getSender());
                    adicionarMensagem(msg.getTexto(), isAluno);
                }

                Platform.runLater(() -> {
                    if (messageScrollPane != null) messageScrollPane.setVvalue(1.0);
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        overlayPane.setVisible(true);
        chatContainer.setVisible(true);
    }

    private void adicionarMensagem(String texto, boolean isAluno) {
        Label messageLabel = new Label(texto);
        messageLabel.setWrapText(true);
        messageLabel.setMaxWidth(400);
        messageLabel.getStyleClass().add("message-bubble");

        HBox messageBox = new HBox(messageLabel);
        if (isAluno) {
            messageLabel.getStyleClass().add("student-bubble");
            messageBox.setAlignment(Pos.CENTER_LEFT);
        } else {
            messageLabel.getStyleClass().add("professor-bubble");
            messageBox.setAlignment(Pos.CENTER_RIGHT);
        }

        if (messageVBox != null) messageVBox.getChildren().add(messageBox);
    }

    @FXML
    private void fecharChat() {
        chatContainer.setVisible(false);
        overlayPane.setVisible(false);
        emailAlunoChatAtual = null;
    }

    // =================== LISTA DE ALUNOS / SOLICITAÇÕES ===================

    private void carregarAlunosAceitos() {
        try {
            Usuario profLogado = Sessao.getUsuario();
            if (profLogado == null) return;

            SolicitacaoDAO solDAO = new SolicitacaoDAO();
            List<Usuario> alunosAceitosLista = solDAO.listarAlunosAceitos(profLogado.getEmail());

            alunosAtivos.clear();
            int id = 1;
            for (Usuario aluno : alunosAceitosLista) {
                alunosAtivos.add(new Aluno(id++, aluno.getNome(), aluno.getEmail(), "Você tem novas mensagens"));
            }

            atualizarListaAlunosUI();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void atualizarListaAlunosUI() {
        if (listaAlunosVBox == null) return;
        listaAlunosVBox.getChildren().clear();

        for (Aluno a : alunosAtivos) {
            listaAlunosVBox.getChildren().add(criarItemAluno(a.nome, a.status, a.email));
        }
    }

    private HBox criarItemAluno(String nome, String status, String email) {
        StackPane circleContainer = new StackPane(new Circle(22, Color.web("#E0E0E0")));
        circleContainer.setPrefSize(44, 44);

        Label labelNome = new Label(nome);
        labelNome.getStyleClass().add("aluno-name");

        Label labelStatus = new Label(status);
        labelStatus.getStyleClass().add("aluno-status");

        VBox textVBox = new VBox(labelNome, labelStatus);
        textVBox.setAlignment(Pos.CENTER_LEFT);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnSecoes = new Button("SEÇÕES");
        btnSecoes.getStyleClass().add("btn-secoes");

        HBox item = new HBox(15, circleContainer, textVBox, spacer);
        item.getStyleClass().add("list-item");
        item.setAlignment(Pos.CENTER_LEFT);

        // clique no item abre chat
        item.setOnMouseClicked(event -> abrirChatPopup(nome, email));

        btnSecoes.setOnMouseEntered(e -> item.setStyle("-fx-background-color: #E8E8E8; -fx-cursor: default;"));
        btnSecoes.setOnMouseExited(e -> item.setStyle(""));

        // clique no botão abre tela de seções
        btnSecoes.setOnMouseClicked(e -> {
            abrirSecao(nome, email, btnSecoes); // passa o próprio botão como source
            e.consume();
        });

        item.getChildren().add(btnSecoes);
        return item;
    }

    private void carregarSolicitacoes() {
        try {
            Usuario profLogado = Sessao.getUsuario();
            if (profLogado == null || solicitacoesVBox == null) return;

            SolicitacaoDAO solDAO = new SolicitacaoDAO();
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            List<Solicitacao> solicitacoesPendentes = solDAO.listarSolicitacoesPendentes(profLogado.getEmail());

            solicitacoesVBox.getChildren().clear();

            for (Solicitacao sol : solicitacoesPendentes) {
                Usuario aluno = usuarioDAO.buscarPorEmail(sol.getEmailAluno());
                String cursoAluno = (aluno != null) ? aluno.getCurso() : "Curso não informado";
                solicitacoesVBox.getChildren().add(
                        criarItemSolicitacao(sol.getNomeAluno(), cursoAluno, sol.getEmailAluno())
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Node criarItemSolicitacao(String nomeAluno, String cursoAluno, String emailAluno) {
        StackPane circleContainer = new StackPane(new Circle(30, Color.web("#E0E0E0")));
        circleContainer.setPrefSize(60, 60);

        Label labelNome = new Label(nomeAluno);
        labelNome.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #333;");

        Label labelCurso = new Label(cursoAluno);
        labelCurso.setStyle("-fx-font-size: 12px; -fx-text-fill: #666; -fx-wrap-text: true;");
        labelCurso.setWrapText(true);
        labelCurso.setMaxWidth(180);

        VBox infoVBox = new VBox(3, labelNome, labelCurso);
        infoVBox.setAlignment(Pos.CENTER_LEFT);

        HBox topRow = new HBox(15, circleContainer, infoVBox);
        topRow.setAlignment(Pos.CENTER_LEFT);
        topRow.setPadding(new javafx.geometry.Insets(0, 0, 10, 0));

        Button btnAprovar = new Button("APROVAR");
        btnAprovar.getStyleClass().add("btn-aprovar");
        btnAprovar.setOnAction(e -> abrirDialogAprovacao(emailAluno));

        Button btnRecusar = new Button("RECUSAR");
        btnRecusar.getStyleClass().add("btn-recusar");
        btnRecusar.setOnAction(e -> abrirDialogRecusa(emailAluno));

        HBox buttonsRow = new HBox(10, btnRecusar, btnAprovar);
        buttonsRow.setAlignment(Pos.CENTER);

        VBox solicitacaoItem = new VBox(10, topRow, buttonsRow);
        solicitacaoItem.getStyleClass().add("solicitacao-item");

        return solicitacaoItem;
    }

    // =================== APROVAÇÃO ===================

    @FXML
    private void abrirDialogAprovacao(String emailAluno) {
        emailAlunoAprovacaoPendente = emailAluno;
        mostrarDialog(aprovacaoDialog);
    }

    @FXML
    private void confirmarAprovacao() {
        try {
            Usuario profLogado = Sessao.getUsuario();
            if (profLogado == null || emailAlunoAprovacaoPendente == null) return;

            SolicitacaoDAO solDAO = new SolicitacaoDAO();
            solDAO.atualizarStatus(emailAlunoAprovacaoPendente, profLogado.getEmail(), 2);

            if (aprovacaoDialog != null) aprovacaoDialog.setVisible(false);
            if (sucessoAprovacaoDialog != null) sucessoAprovacaoDialog.setVisible(true);

            carregarSolicitacoes();
            carregarAlunosAceitos();

            emailAlunoAprovacaoPendente = null;
        } catch (Exception e) {
            e.printStackTrace();
            mostrarErro("Erro ao aprovar", "Falha ao aprovar solicitação: " + e.getMessage());
        }
    }

    @FXML
    private void fecharAprovacaoDialog() {
        fecharDialog(aprovacaoDialog);
        emailAlunoAprovacaoPendente = null;
    }

    @FXML
    private void fecharSucessoAprovacaoDialog() {
        fecharDialog(sucessoAprovacaoDialog);
    }

    // =================== RECUSA ===================

    @FXML
    private void abrirDialogRecusa(String emailAluno) {
        emailAlunoRecusaPendente = emailAluno;
        limparCheckboxes();
        mostrarDialog(recusaDialog);
    }

    @FXML
    private void confirmarRecusa() {
        if (!algumCheckboxSelecionado()) {
            mostrarAviso("Por favor, selecione uma justificativa antes de confirmar.");
            return;
        }

        try {
            Usuario profLogado = Sessao.getUsuario();
            if (profLogado == null || emailAlunoRecusaPendente == null) return;

            SolicitacaoDAO solDAO = new SolicitacaoDAO();
            solDAO.atualizarStatus(emailAlunoRecusaPendente, profLogado.getEmail(), 3);

            if (recusaDialog != null) recusaDialog.setVisible(false);
            if (sucessoDialog != null) sucessoDialog.setVisible(true);

            carregarSolicitacoes();
            emailAlunoRecusaPendente = null;
        } catch (Exception e) {
            e.printStackTrace();
            mostrarErro("Erro ao recusar", "Falha ao recusar solicitação: " + e.getMessage());
        }
    }

    @FXML
    private void fecharRecusaDialog() {
        fecharDialog(recusaDialog);
        emailAlunoRecusaPendente = null;
    }

    @FXML
    private void fecharSucessoDialog() {
        fecharDialog(sucessoDialog);
    }

    private void limparCheckboxes() {
        if (justificativa1 != null) justificativa1.setSelected(false);
        if (justificativa2 != null) justificativa2.setSelected(false);
        if (justificativa3 != null) justificativa3.setSelected(false);
    }

    private boolean algumCheckboxSelecionado() {
        return (justificativa1 != null && justificativa1.isSelected()) ||
               (justificativa2 != null && justificativa2.isSelected()) ||
               (justificativa3 != null && justificativa3.isSelected());
    }

    // =================== NAVEGAÇÃO ===================

    @FXML
    private void addProf(ActionEvent event) {
        navegarPara("/org/example/telacad/Cadastro-prof.fxml", "Cadastrar Professor", addUserButton);
    }

    @FXML
    private void abrirPerfil() {
        try {
            Stage stagePrincipal = (Stage) perfilBtn.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/telacad/Perfil_Professor.fxml"));
            Parent root = loader.load();

            Stage popupStage = new Stage();
            popupStage.initOwner(stagePrincipal);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.initStyle(StageStyle.TRANSPARENT);
            popupStage.setMaximized(true);

            Scene scene = new Scene(root);
            scene.setFill(Color.TRANSPARENT);
            popupStage.setScene(scene);
            popupStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void voltarParaLogin(ActionEvent e) {
        navegarPara("/org/example/telacad/LoginView.fxml", "Login", (Node) e.getSource());
    }

    @FXML
    private void minhaorientacao(ActionEvent event) {
        Node sourceNode = (Node) event.getSource();
        navegarPara("/org/example/telacad/MinhaOrientacao.fxml", "Minha Orientação", sourceNode);
    }

    private void navegarPara(String fxmlPath, String titulo, Node sourceNode) {
        try {
            Stage stage = (Stage) sourceNode.getScene().getWindow();
            Parent page = FXMLLoader.load(getClass().getResource(fxmlPath));
            Scene scene = new Scene(page);
            stage.setScene(scene);
            stage.setTitle(titulo);
            stage.setMaximized(true);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // =================== DOCUMENTOS ===================

    @FXML
    private void handleOpenDocuments(ActionEvent event) {
        if (emailAlunoChatAtual != null) {
            carregarDocumentosAluno(emailAlunoChatAtual);
        } else {
            if (docListVBox != null) docListVBox.getChildren().clear();
            if (docEmptyMessageLabel != null) docEmptyMessageLabel.setVisible(true);
            if (docScrollPane != null) docScrollPane.setVisible(false);
            mostrarDialog(documentPopupVBox);
        }
    }

    @FXML
    private void closeDocumentPopup(ActionEvent event) {
        fecharDialog(documentPopupVBox);
    }

    private void carregarDocumentosAluno(String emailAluno) {
        try {
            Usuario prof = Sessao.getUsuario();
            if (prof == null || docListVBox == null) return;

            DocumentoDAO dao = new DocumentoDAO();
            List<Documento> documentos = dao.listarDocumentos(emailAluno, prof.getEmail());

            docListVBox.getChildren().clear();

            if (documentos.isEmpty()) {
                if (docEmptyMessageLabel != null) docEmptyMessageLabel.setVisible(true);
                if (docScrollPane != null) docScrollPane.setVisible(false);
            } else {
                if (docEmptyMessageLabel != null) docEmptyMessageLabel.setVisible(false);
                if (docScrollPane != null) docScrollPane.setVisible(true);

                for (Documento doc : documentos) {
                    docListVBox.getChildren().add(criarItemDocumento(doc));
                }
            }

            mostrarDialog(documentPopupVBox);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarErro("Erro ao carregar documentos", "Falha ao carregar documentos: " + e.getMessage());
        }
    }

    private HBox criarItemDocumento(Documento documento) {
        SVGPath docIcon = new SVGPath();
        docIcon.setContent("M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z");
        docIcon.getStyleClass().add("document-icon-style");

        Label nameLabel = new Label(documento.getNomeArquivo());
        nameLabel.getStyleClass().add("document-name-style");

        Label sizeLabel = new Label(documento.getTamanhoFormatado());
        sizeLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #666;");

        VBox infoBox = new VBox(2, nameLabel, sizeLabel);

        Button downloadBtn = new Button("⬇ Baixar");
        downloadBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 5 10;");
        downloadBtn.setOnAction(e -> baixarDocumento(documento));

        HBox item = new HBox(10, docIcon, infoBox, downloadBtn);
        item.getStyleClass().add("document-item-style");
        item.setAlignment(Pos.CENTER_LEFT);
        item.setStyle("-fx-padding: 10; -fx-background-color: #f5f5f5; -fx-background-radius: 5;");

        return item;
    }

    private void baixarDocumento(Documento documento) {
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Salvar Arquivo");
            fileChooser.setInitialFileName(documento.getNomeArquivo());

            File destino = fileChooser.showSaveDialog(sairBtn.getScene().getWindow());

            if (destino != null) {
                Path origem = Paths.get(documento.getCaminhoArquivo());
                Files.copy(origem, destino.toPath(), StandardCopyOption.REPLACE_EXISTING);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Sucesso");
                alert.setHeaderText(null);
                alert.setContentText("Arquivo baixado com sucesso!");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
            mostrarErro("Erro ao baixar", "Falha ao baixar arquivo: " + e.getMessage());
        }
    }

    @FXML
    private void handleUploadFileToStudent(ActionEvent event) {
        if (emailAlunoChatAtual == null) {
            mostrarAviso("Nenhum aluno selecionado.");
            return;
        }

        Usuario prof = Sessao.getUsuario();
        if (prof == null) return;

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecionar Arquivo");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Todos os Arquivos", "*.*"),
                new FileChooser.ExtensionFilter("Documentos", "*.pdf", "*.doc", "*.docx", "*.txt"),
                new FileChooser.ExtensionFilter("Imagens", "*.png", "*.jpg", "*.jpeg", "*.gif"),
                new FileChooser.ExtensionFilter("Planilhas", "*.xls", "*.xlsx", "*.csv")
        );

        File selectedFile = fileChooser.showOpenDialog(sairBtn.getScene().getWindow());

        if (selectedFile != null) {
            try {
                File uploadDir = new File("uploads/");
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                String nomeArquivo = System.currentTimeMillis() + "_" + selectedFile.getName();
                Path destino = Paths.get("uploads/" + nomeArquivo);
                Files.copy(selectedFile.toPath(), destino, StandardCopyOption.REPLACE_EXISTING);

                DocumentoDAO dao = new DocumentoDAO();
                dao.salvarDocumento(
                        emailAlunoChatAtual,
                        prof.getEmail(),
                        selectedFile.getName(),
                        destino.toString(),
                        selectedFile.length(),
                        getFileExtension(selectedFile.getName())
                );

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Sucesso");
                alert.setHeaderText(null);
                alert.setContentText("Arquivo enviado com sucesso para o aluno!");
                alert.showAndWait();
            } catch (Exception e) {
                e.printStackTrace();
                mostrarErro("Erro ao enviar", "Falha ao enviar arquivo: " + e.getMessage());
            }
        }
    }

    private String getFileExtension(String fileName) {
        int lastDot = fileName.lastIndexOf('.');
        return (lastDot > 0) ? fileName.substring(lastDot + 1) : "";
    }

    // =================== SEÇÕES ===================

    private void abrirSecao(String nomeAluno, String emailAluno, Node sourceNode) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/org/example/telacad/secao.fxml")
            );
            Parent root = loader.load();

            SecaoController controller = loader.getController();
            if (controller != null) {
                controller.setNomeAluno(nomeAluno);
                controller.setEmailAluno(emailAluno);

                Usuario profLogado = Sessao.getUsuario();
                if (profLogado != null) {
                    controller.setEmailProfessor(profLogado.getEmail());
                }

                controller.inicializarTela();
            }

            // pega a janela principal (HomeP)
            Stage stagePrincipal = (Stage) sourceNode.getScene().getWindow();

            // cria UMA NOVA janela para as seções
            Stage secaoStage = new Stage();
            secaoStage.initOwner(stagePrincipal);                 // HomeP é "dono"
            secaoStage.initModality(Modality.APPLICATION_MODAL);  // trava HomeP enquanto estiver aberta (se não quiser, tira essa linha)
            secaoStage.setTitle("Seções - " + nomeAluno);

            Scene scene = new Scene(root);
            secaoStage.setScene(scene);
            secaoStage.setMaximized(true);
            secaoStage.show();

        } catch (IOException e) {
            e.printStackTrace();
            mostrarErro("Erro",
                    "Não foi possível abrir a tela de seções.\n" +
                    "Verifique se o arquivo 'secao.fxml' existe.\nErro: " + e.getMessage());
        }
    }


    // =================== UTILITÁRIOS ===================

    private void mostrarDialog(VBox dialog) {
        if (overlayPane != null) overlayPane.setVisible(true);
        if (dialog != null) dialog.setVisible(true);
    }

    private void fecharDialog(VBox dialog) {
        if (dialog != null) dialog.setVisible(false);
        if (overlayPane != null) overlayPane.setVisible(false);
    }

    private void mostrarErro(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    private void mostrarAviso(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
