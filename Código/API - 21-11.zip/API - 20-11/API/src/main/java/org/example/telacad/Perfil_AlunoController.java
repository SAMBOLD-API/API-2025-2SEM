package org.example.telacad;

import org.example.telacad.db.UsuarioDAO;
import org.example.telacad.models.Usuario;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Perfil_AlunoController {

    @FXML private Button closeButton;
    @FXML private Button atualizarBtn;
    @FXML private VBox dialogPane;
    @FXML private TextField nomeField;
    @FXML private TextField emailField;
    @FXML private PasswordField senhaField;
    @FXML private PasswordField confirmarSenhaField;
    @FXML private TextField cursoTextField;

    @FXML private Button okButton;
    @FXML private VBox sucessoDialog;
    @FXML private VBox cursosDialog;
    @FXML private ToggleGroup cursoToggleGroup;
    @FXML private VBox overlayPane;

    private double xOffset = 0;
    private double yOffset = 0;

    @FXML
    public void initialize() {
        setupDraggable(dialogPane);
        carregarDadosUsuario();
    }

    private void carregarDadosUsuario() {
        Usuario usuario = Sessao.getUsuario();
        if (usuario != null) {
            if (nomeField != null) nomeField.setText(usuario.getNome());
            if (emailField != null) emailField.setText(usuario.getEmail());
            if (cursoTextField != null) cursoTextField.setText(usuario.getCurso());
        }
    }

    @FXML
    private void handleAbrirCursosDialog() {
        if (overlayPane != null) overlayPane.setVisible(true);
        if (dialogPane != null) dialogPane.setDisable(true);
        if (cursosDialog != null) cursosDialog.setVisible(true);
    }

    @FXML
    private void handleConfirmarCursos() {
        if (cursoToggleGroup != null && cursoToggleGroup.getSelectedToggle() != null) {
            RadioButton selectedRadioButton = (RadioButton) cursoToggleGroup.getSelectedToggle();
            if (cursoTextField != null) cursoTextField.setText(selectedRadioButton.getText());
        }
        if (overlayPane != null) overlayPane.setVisible(false);
        if (cursosDialog != null) cursosDialog.setVisible(false);
        if (dialogPane != null) dialogPane.setDisable(false);
    }

    @FXML
    private void handleAtualizar() {
        try {
            Usuario usuarioAtual = Sessao.getUsuario();
            if (usuarioAtual == null) {
                mostrarAlerta("Erro", "Sessão inválida. Faça login novamente.");
                return;
            }

            // Valores digitados (podem vir vazios)
            String nomeDigitado   = nomeField        != null ? nomeField.getText().trim()           : "";
            String emailDigitado  = emailField       != null ? emailField.getText().trim()          : "";
            String cursoDigitado  = cursoTextField   != null ? cursoTextField.getText().trim()      : "";
            String senhaDigitada  = senhaField       != null ? senhaField.getText()                 : "";
            String confirmSenha   = confirmarSenhaField != null ? confirmarSenhaField.getText()     : "";

            // Se absolutamente nada foi informado, não faz sentido atualizar
            boolean nenhumCampoPreenchido =
                    nomeDigitado.isEmpty() &&
                    emailDigitado.isEmpty() &&
                    cursoDigitado.isEmpty() &&
                    senhaDigitada.isEmpty() &&
                    confirmSenha.isEmpty();

            if (nenhumCampoPreenchido) {
                mostrarAlerta("Aviso", "Nenhuma alteração foi informada.");
                return;
            }

            // Regras de senha: só altera se os DOIS campos estiverem preenchidos
            String novaSenha = null;
            boolean querAlterarSenha = !senhaDigitada.isEmpty() || !confirmSenha.isEmpty();

            if (querAlterarSenha) {
                if (senhaDigitada.isEmpty() || confirmSenha.isEmpty()) {
                    mostrarAlerta("Erro", "Para alterar a senha, preencha os dois campos de senha.");
                    return;
                }
                if (!senhaDigitada.equals(confirmSenha)) {
                    mostrarAlerta("Erro", "As senhas não conferem.");
                    return;
                }
                novaSenha = senhaDigitada;
            }

            // Se o campo estiver vazio, mantemos o valor atual do usuário
            String nomeFinal  = nomeDigitado.isEmpty()  ? usuarioAtual.getNome()   : nomeDigitado;
            String emailFinal = emailDigitado.isEmpty() ? usuarioAtual.getEmail()  : emailDigitado;
            String cursoFinal = cursoDigitado.isEmpty() ? usuarioAtual.getCurso()  : cursoDigitado;

            // Chama o DAO passando sempre os valores finais.
            // Se novaSenha for null, o DAO não mexe na senha.
            UsuarioDAO dao = new UsuarioDAO();
            dao.atualizarUsuario(usuarioAtual.getEmail(), emailFinal, nomeFinal, cursoFinal, novaSenha);

            // Atualiza a sessão com os dados que realmente ficaram salvos
            Usuario usuarioAtualizado = new Usuario(
                    emailFinal,
                    nomeFinal,
                    cursoFinal,
                    (novaSenha != null ? novaSenha : usuarioAtual.getSenha()),
                    usuarioAtual.getPerfil(),
                    usuarioAtual.getStatus()
            );
            Sessao.setUsuario(usuarioAtualizado);

            // Mostra popup de sucesso
            if (overlayPane != null) overlayPane.setVisible(true);
            if (dialogPane != null) dialogPane.setVisible(false);
            if (cursosDialog != null) cursosDialog.setVisible(false);
            if (sucessoDialog != null) sucessoDialog.setVisible(true);

        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Erro", "Falha ao atualizar: " + e.getMessage());
        }
    }

    @FXML
    private void okButton() {
        // Botão OK do pop-up de sucesso
        handleClose();
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        try {
            // Ajuste o caminho EXATO para o FXML da tela Home do Aluno
            Parent root = FXMLLoader.load(
                    getClass().getResource("/org/example/telacad/home-aluno.fxml")
            );

            if (root != null) {
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.centerOnScreen();
                return; // já trocou de tela, sai do método
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Se quiser, pode mostrar alerta aqui também
            // mostrarAlerta("Erro", "Não foi possível voltar para a tela inicial: " + e.getMessage());
        }

        // Se der qualquer problema ao carregar o FXML, pelo menos fecha só essa janela
        stage.close();
    }

    private void setupDraggable(VBox pane) {
        if (pane == null) return;
        pane.setOnMousePressed(event -> {
            xOffset = event.getSceneX();
            yOffset = event.getSceneY();
        });

        pane.setOnMouseDragged(event -> {
            Stage stage = (Stage) pane.getScene().getWindow();
            stage.setX(event.getScreenX() - xOffset);
            stage.setY(event.getScreenY() - yOffset);
        });
    }

    private void mostrarAlerta(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
