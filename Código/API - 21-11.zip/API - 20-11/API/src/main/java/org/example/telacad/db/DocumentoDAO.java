package org.example.telacad.db;

import org.example.telacad.models.Documento;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DocumentoDAO {

    // Salvar documento no banco
    public void salvarDocumento(String emailAluno, String emailProf, String nomeArquivo, 
                                String caminhoArquivo, long tamanhoBytes, String tipoArquivo) throws SQLException {
        String sql = "INSERT INTO documento (email_aluno, email_prof, nome_arquivo, caminho_arquivo, tamanho_bytes, tipo_arquivo) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            ps.setString(3, nomeArquivo);
            ps.setString(4, caminhoArquivo);
            ps.setLong(5, tamanhoBytes);
            ps.setString(6, tipoArquivo);
            ps.executeUpdate();
        }
    }

    // Listar documentos enviados pelo aluno para o professor
    public List<Documento> listarDocumentos(String emailAluno, String emailProf) throws SQLException {
        String sql = "SELECT id, email_aluno, email_prof, nome_arquivo, caminho_arquivo, " +
                     "tamanho_bytes, tipo_arquivo, data_upload " +
                     "FROM documento " +
                     "WHERE email_aluno = ? AND email_prof = ? " +
                     "ORDER BY data_upload DESC";
        
        List<Documento> documentos = new ArrayList<>();
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emailAluno);
            ps.setString(2, emailProf);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Documento doc = new Documento(
                        rs.getInt("id"),
                        rs.getString("email_aluno"),
                        rs.getString("email_prof"),
                        rs.getString("nome_arquivo"),
                        rs.getString("caminho_arquivo"),
                        rs.getLong("tamanho_bytes"),
                        rs.getString("tipo_arquivo"),
                        rs.getTimestamp("data_upload").toLocalDateTime()
                    );
                    documentos.add(doc);
                }
            }
        }
        return documentos;
    }

    // Deletar documento
    public void deletarDocumento(int id) throws SQLException {
        String sql = "DELETE FROM documento WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // Buscar documento por ID
    public Documento buscarPorId(int id) throws SQLException {
        String sql = "SELECT id, email_aluno, email_prof, nome_arquivo, caminho_arquivo, " +
                     "tamanho_bytes, tipo_arquivo, data_upload " +
                     "FROM documento WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Documento(
                        rs.getInt("id"),
                        rs.getString("email_aluno"),
                        rs.getString("email_prof"),
                        rs.getString("nome_arquivo"),
                        rs.getString("caminho_arquivo"),
                        rs.getLong("tamanho_bytes"),
                        rs.getString("tipo_arquivo"),
                        rs.getTimestamp("data_upload").toLocalDateTime()
                    );
                }
            }
        }
        return null;
    }
}
