package org.example.telacad;

public class HomePController {
    
}
